# 🛍️ Dipus Candor — E-Commerce Platform

> Full-stack Next.js 14 e-commerce platform with AI chatbot and triple payment gateway integration (Stripe + Razorpay + bKash).

---

## 🚀 Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Next.js 14 (App Router) + TypeScript + Tailwind CSS |
| Backend | Next.js API Routes + Node.js |
| Database | PostgreSQL + Prisma ORM |
| Cache | Redis (sessions, product cache) |
| Auth | NextAuth.js (Email + Google OAuth) |
| Payments | Stripe + Razorpay + bKash |
| AI Chatbot | OpenAI GPT-4o-mini |
| Email | Nodemailer + SendGrid |
| SMS | Twilio |
| Storage | Cloudinary |
| Deployment | Vercel (frontend) + AWS EC2 (backend) |

---

## ⚡ Quick Start

### 1. Prerequisites

```bash
node >= 20
postgresql >= 15
redis >= 7
```

### 2. Clone & Install

```bash
git clone https://github.com/yourname/dipus-candor.git
cd dipus-candor
npm install
```

### 3. Configure Environment

```bash
cp .env.example .env
# Edit .env with your credentials
```

**Required variables:**
- `DATABASE_URL` — PostgreSQL connection string
- `NEXTAUTH_SECRET` — Random 32+ char string
- `STRIPE_SECRET_KEY` — From Stripe Dashboard
- `RAZORPAY_KEY_ID` + `RAZORPAY_KEY_SECRET` — From Razorpay Dashboard  
- `BKASH_APP_KEY` + `BKASH_APP_SECRET` — From bKash Developer Portal
- `OPENAI_API_KEY` — From OpenAI Platform

### 4. Database Setup

```bash
# Generate Prisma client
npm run db:generate

# Run migrations
npm run db:migrate

# Seed with sample data
npm run db:seed
```

### 5. Run Development Server

```bash
npm run dev
# → http://localhost:3000
# → Admin: http://localhost:3000/admin
```

---

## 💳 Payment Gateway Setup

### Stripe (International Cards)

1. Create account at [stripe.com](https://stripe.com)
2. Get API keys from Dashboard → Developers → API Keys
3. Set up webhook: Dashboard → Webhooks → Add endpoint
   - URL: `https://yourdomain.com/api/payment/stripe/webhook`
   - Events: `payment_intent.succeeded`, `payment_intent.payment_failed`, `charge.refunded`
4. Add webhook secret to `.env`

### Razorpay (India / UPI)

1. Create account at [razorpay.com](https://razorpay.com)
2. Get Key ID and Secret from Settings → API Keys
3. Set up webhook: Settings → Webhooks
   - URL: `https://yourdomain.com/api/payment/razorpay/webhook`
   - Events: `payment.captured`, `payment.failed`

### bKash (Bangladesh)

1. Register as merchant at [developer.bka.sh](https://developer.bka.sh)
2. Get sandbox credentials for testing
3. Sandbox base URL: `https://tokenized.sandbox.bka.sh/v1.2.0-beta`
4. Production URL: `https://tokenized.pay.bka.sh/v1.2.0-beta`
5. Callback URL: `https://yourdomain.com/api/payment/bkash/callback`

---

## 📁 Project Structure

```
dipus-candor/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── auth/           # NextAuth endpoints
│   │   │   ├── products/       # Product CRUD + search
│   │   │   ├── orders/         # Order management
│   │   │   ├── payment/
│   │   │   │   ├── create/     # Unified payment creation
│   │   │   │   ├── stripe/     # Stripe webhook
│   │   │   │   ├── razorpay/   # Razorpay verify + webhook
│   │   │   │   └── bkash/      # bKash callback
│   │   │   ├── cart/           # Cart management
│   │   │   └── chat/           # AI chatbot (OpenAI)
│   │   ├── (shop)/             # Customer pages
│   │   ├── admin/              # Admin dashboard
│   │   └── checkout/           # Checkout flow
│   ├── components/
│   │   ├── ui/                 # Reusable UI components
│   │   ├── shop/               # Product cards, filters
│   │   ├── checkout/           # Payment forms
│   │   └── chatbot/            # AI chat widget
│   ├── lib/
│   │   ├── prisma.ts           # DB client
│   │   ├── auth.ts             # NextAuth config
│   │   ├── email.ts            # Email service
│   │   ├── sms.ts              # Twilio SMS
│   │   └── payments/
│   │       ├── stripe.ts       # Stripe integration
│   │       ├── razorpay.ts     # Razorpay integration
│   │       └── bkash.ts        # bKash integration
│   └── types/                  # TypeScript types
├── prisma/
│   ├── schema.prisma           # Full DB schema
│   └── seed.ts                 # Sample data
└── .env.example                # Environment template
```

---

## 🗄️ Database Tables

| Table | Purpose |
|---|---|
| `users` | Customers, admins, delivery staff |
| `categories` | Product categories (nested) |
| `products` | Product catalog with variants |
| `product_variants` | Size/color variants |
| `cart_items` | Persistent shopping cart |
| `orders` | Order management |
| `order_items` | Line items per order |
| `tracking_logs` | Order status history |
| `payments` | Payment records (all gateways) |
| `coupons` | Discount codes |
| `flash_sales` | Time-limited deals |
| `reviews` | Product reviews + ratings |
| `wishlist_items` | User wishlists |
| `chat_sessions` | AI chat history |
| `notifications` | Push/in-app alerts |
| `admin_logs` | Audit trail |

---

## 🔌 API Endpoints

```
POST   /api/auth/register           Register new user
POST   /api/auth/login              Login (NextAuth)
GET    /api/products                List/search products
GET    /api/products/[id]           Single product
POST   /api/cart                    Add to cart
GET    /api/cart                    Get cart
POST   /api/orders                  Create order
GET    /api/orders                  List user orders
GET    /api/orders/[id]             Order details
POST   /api/payment/create          Initiate payment (all gateways)
POST   /api/payment/stripe/webhook  Stripe events
GET    /api/payment/bkash/callback  bKash redirect handler
POST   /api/payment/razorpay/verify Verify Razorpay payment
POST   /api/chat                    AI chatbot message
GET    /api/admin/dashboard         Admin stats
```

---

## 🚢 Deployment

### Vercel (Frontend)

```bash
npm install -g vercel
vercel --prod
# Set all env vars in Vercel dashboard
```

### AWS EC2 (Optional self-hosted backend)

```bash
# On EC2 (Ubuntu 24.04)
sudo apt update && sudo apt install -y nodejs npm postgresql redis-server nginx
git clone ... && cd dipus-candor && npm install
npm run db:migrate && npm run db:seed
npm run build && npm start
```

### Docker Compose

```yaml
version: '3.8'
services:
  app:
    build: .
    ports: ["3000:3000"]
    env_file: .env
    depends_on: [postgres, redis]
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: dipus_candor
      POSTGRES_PASSWORD: password
    volumes: [pgdata:/var/lib/postgresql/data]
  redis:
    image: redis:7-alpine
volumes:
  pgdata:
```

---

## 👤 Default Credentials (After Seeding)

```
Admin:    admin@dipuscandor.com  /  Admin@123!
Customer: customer@example.com   /  Customer@123
```

---

## 📊 Admin Dashboard

Access at `/admin` — features:

- 📈 Sales analytics (daily/weekly/monthly)
- 📦 Product management (CRUD + bulk import)
- 🛒 Order management (status updates, invoices)
- 👥 Customer management
- 💰 Payment & refund processing
- 🚚 Delivery management
- 📢 Marketing (coupons, flash sales, push notifications)
- 🤖 AI chatbot training panel
- ⚙️ Store settings

---

## 📱 Android App

Built with Flutter. See `/android-app` folder.

```bash
cd android-app
flutter pub get
flutter run
```

---

## 🔐 Security

- JWT authentication with HttpOnly cookies
- Bcrypt password hashing (12 rounds)
- CSRF protection via NextAuth
- Rate limiting on auth endpoints
- Stripe/Razorpay/bKash webhook signature verification
- Input validation with Zod
- SQL injection prevention via Prisma ORM
- XSS protection via React's built-in escaping

---

## 📞 Support

- Email: support@dipuscandor.com
- Docs: https://docs.dipuscandor.com
