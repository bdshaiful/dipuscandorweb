// src/lib/payments/stripe.ts
import Stripe from 'stripe'
import prisma from '@/lib/prisma'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20',
  typescript: true,
})

export interface CreateStripePaymentParams {
  orderId: string
  amount: number       // in smallest currency unit (cents/paisa)
  currency?: string
  customerEmail?: string
  customerName?: string
  metadata?: Record<string, string>
}

/**
 * Create a Stripe Payment Intent
 * Returns clientSecret for frontend to complete payment
 */
export async function createStripePaymentIntent({
  orderId,
  amount,
  currency = 'usd',
  customerEmail,
  customerName,
  metadata = {},
}: CreateStripePaymentParams) {
  const paymentIntent = await stripe.paymentIntents.create({
    amount: Math.round(amount * 100), // convert to cents
    currency,
    automatic_payment_methods: { enabled: true },
    receipt_email: customerEmail,
    metadata: {
      orderId,
      platform: 'dipus-candor',
      ...metadata,
    },
    description: `Order ${orderId} - Dipus Candor`,
  })

  // Store in DB
  await prisma.payment.upsert({
    where: { orderId },
    create: {
      orderId,
      amount,
      currency: currency.toUpperCase(),
      method: 'STRIPE',
      status: 'PENDING',
      gatewayOrderId: paymentIntent.id,
    },
    update: {
      gatewayOrderId: paymentIntent.id,
    },
  })

  return {
    clientSecret: paymentIntent.client_secret,
    paymentIntentId: paymentIntent.id,
  }
}

/**
 * Handle Stripe Webhook Events
 */
export async function handleStripeWebhook(
  payload: Buffer,
  signature: string
): Promise<{ received: boolean }> {
  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(
      payload,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    )
  } catch (err) {
    throw new Error(`Stripe webhook signature verification failed: ${err}`)
  }

  switch (event.type) {
    case 'payment_intent.succeeded': {
      const intent = event.data.object as Stripe.PaymentIntent
      const orderId = intent.metadata.orderId

      await prisma.$transaction([
        prisma.payment.update({
          where: { orderId },
          data: {
            status: 'PAID',
            gatewayTxnId: intent.id,
            paidAt: new Date(),
          },
        }),
        prisma.order.update({
          where: { id: orderId },
          data: {
            paymentStatus: 'PAID',
            orderStatus: 'CONFIRMED',
          },
        }),
        prisma.trackingLog.create({
          data: {
            orderId,
            status: 'CONFIRMED',
            message: 'Payment confirmed via Stripe. Order is being processed.',
          },
        }),
      ])
      break
    }

    case 'payment_intent.payment_failed': {
      const intent = event.data.object as Stripe.PaymentIntent
      const orderId = intent.metadata.orderId

      await prisma.payment.update({
        where: { orderId },
        data: {
          status: 'FAILED',
          failureReason: intent.last_payment_error?.message,
        },
      })
      break
    }

    case 'charge.refunded': {
      const charge = event.data.object as Stripe.Charge
      const paymentIntentId = charge.payment_intent as string

      await prisma.payment.updateMany({
        where: { gatewayOrderId: paymentIntentId },
        data: {
          status: 'REFUNDED',
          refundAmount: charge.amount_refunded / 100,
        },
      })
      break
    }
  }

  return { received: true }
}

/**
 * Issue a full or partial refund via Stripe
 */
export async function createStripeRefund(
  paymentIntentId: string,
  amount?: number
) {
  const refund = await stripe.refunds.create({
    payment_intent: paymentIntentId,
    ...(amount && { amount: Math.round(amount * 100) }),
  })
  return refund
}
