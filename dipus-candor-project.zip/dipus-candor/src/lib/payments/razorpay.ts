// src/lib/payments/razorpay.ts
import Razorpay from 'razorpay'
import crypto from 'crypto'
import prisma from '@/lib/prisma'

export const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
})

export interface CreateRazorpayOrderParams {
  orderId: string
  amount: number     // in INR (will be converted to paise)
  currency?: string
  receipt?: string
  notes?: Record<string, string>
}

/**
 * Create a Razorpay Order
 * Returns the razorpay order object for frontend checkout
 */
export async function createRazorpayOrder({
  orderId,
  amount,
  currency = 'INR',
  receipt,
  notes = {},
}: CreateRazorpayOrderParams) {
  const rzpOrder = await razorpay.orders.create({
    amount: Math.round(amount * 100), // paise
    currency,
    receipt: receipt || `rcpt_${orderId.slice(0, 30)}`,
    notes: {
      orderId,
      platform: 'dipus-candor',
      ...notes,
    },
  })

  // Persist to DB
  await prisma.payment.upsert({
    where: { orderId },
    create: {
      orderId,
      amount,
      currency,
      method: 'RAZORPAY',
      status: 'PENDING',
      gatewayOrderId: rzpOrder.id,
    },
    update: {
      gatewayOrderId: rzpOrder.id,
    },
  })

  return {
    razorpayOrderId: rzpOrder.id,
    amount: rzpOrder.amount,
    currency: rzpOrder.currency,
    keyId: process.env.RAZORPAY_KEY_ID,
  }
}

/**
 * Verify Razorpay payment signature on the backend
 * Call this after the frontend receives payment success callback
 */
export function verifyRazorpaySignature({
  razorpayOrderId,
  razorpayPaymentId,
  razorpaySignature,
}: {
  razorpayOrderId: string
  razorpayPaymentId: string
  razorpaySignature: string
}): boolean {
  const body = `${razorpayOrderId}|${razorpayPaymentId}`
  const expectedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
    .update(body)
    .digest('hex')
  return expectedSignature === razorpaySignature
}

/**
 * Confirm a Razorpay payment after signature verification
 */
export async function confirmRazorpayPayment({
  orderId,
  razorpayPaymentId,
  razorpayOrderId,
  razorpaySignature,
}: {
  orderId: string
  razorpayPaymentId: string
  razorpayOrderId: string
  razorpaySignature: string
}) {
  const isValid = verifyRazorpaySignature({
    razorpayOrderId,
    razorpayPaymentId,
    razorpaySignature,
  })

  if (!isValid) {
    throw new Error('Razorpay payment signature verification failed')
  }

  await prisma.$transaction([
    prisma.payment.update({
      where: { orderId },
      data: {
        status: 'PAID',
        gatewayTxnId: razorpayPaymentId,
        gatewayPaymentId: razorpayPaymentId,
        paidAt: new Date(),
      },
    }),
    prisma.order.update({
      where: { id: orderId },
      data: {
        paymentStatus: 'PAID',
        orderStatus: 'CONFIRMED',
      },
    }),
    prisma.trackingLog.create({
      data: {
        orderId,
        status: 'CONFIRMED',
        message: 'Payment confirmed via Razorpay. Order is being processed.',
      },
    }),
  ])

  return { success: true, paymentId: razorpayPaymentId }
}

/**
 * Process Razorpay refund
 */
export async function createRazorpayRefund(
  paymentId: string,
  amount?: number,
  notes?: Record<string, string>
) {
  const refund = await razorpay.payments.refund(paymentId, {
    ...(amount && { amount: Math.round(amount * 100) }),
    notes,
  })
  return refund
}

/**
 * Handle Razorpay Webhook
 */
export async function handleRazorpayWebhook(
  payload: string,
  signature: string
): Promise<{ received: boolean }> {
  const expectedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET!)
    .update(payload)
    .digest('hex')

  if (expectedSignature !== signature) {
    throw new Error('Invalid Razorpay webhook signature')
  }

  const event = JSON.parse(payload)

  if (event.event === 'payment.captured') {
    const payment = event.payload.payment.entity
    const orderId = payment.notes?.orderId

    if (orderId) {
      await prisma.payment.update({
        where: { orderId },
        data: { status: 'PAID', paidAt: new Date() },
      })
    }
  }

  return { received: true }
}
