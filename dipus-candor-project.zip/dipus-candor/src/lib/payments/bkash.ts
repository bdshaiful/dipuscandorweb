// src/lib/payments/bkash.ts
// bKash Tokenized Checkout Integration (Sandbox/Production)
import axios from 'axios'
import prisma from '@/lib/prisma'

const BKASH_BASE = process.env.BKASH_BASE_URL!
const APP_KEY    = process.env.BKASH_APP_KEY!
const APP_SECRET = process.env.BKASH_APP_SECRET!
const USERNAME   = process.env.BKASH_USERNAME!
const PASSWORD   = process.env.BKASH_PASSWORD!

let bkashToken: string | null = null
let tokenExpiry: number = 0

// ─── TOKEN MANAGEMENT ─────────────────────────────────────────────────────────

async function getBkashToken(): Promise<string> {
  if (bkashToken && Date.now() < tokenExpiry) return bkashToken

  const res = await axios.post(
    `${BKASH_BASE}/tokenized/checkout/token/grant`,
    {
      app_key: APP_KEY,
      app_secret: APP_SECRET,
    },
    {
      headers: {
        'Content-Type': 'application/json',
        username: USERNAME,
        password: PASSWORD,
      },
    }
  )

  bkashToken = res.data.id_token
  tokenExpiry = Date.now() + (res.data.expires_in - 60) * 1000 // refresh 1 min early
  return bkashToken!
}

// ─── CREATE PAYMENT ───────────────────────────────────────────────────────────

export interface BkashCreatePaymentParams {
  orderId: string
  amount: number      // BDT amount
  callbackUrl: string // URL bKash redirects back to
  merchantInvoiceNumber?: string
}

export async function createBkashPayment({
  orderId,
  amount,
  callbackUrl,
  merchantInvoiceNumber,
}: BkashCreatePaymentParams) {
  const token = await getBkashToken()

  const res = await axios.post(
    `${BKASH_BASE}/tokenized/checkout/create`,
    {
      mode: '0011',
      payerReference: orderId,
      callbackURL: callbackUrl,
      amount: amount.toFixed(2),
      currency: 'BDT',
      intent: 'sale',
      merchantInvoiceNumber: merchantInvoiceNumber || orderId,
    },
    {
      headers: {
        'Content-Type': 'application/json',
        Authorization: token,
        'X-App-Key': APP_KEY,
      },
    }
  )

  const { paymentID, bkashURL } = res.data

  // Store in DB
  await prisma.payment.upsert({
    where: { orderId },
    create: {
      orderId,
      amount,
      currency: 'BDT',
      method: 'BKASH',
      status: 'PENDING',
      gatewayOrderId: paymentID,
    },
    update: {
      gatewayOrderId: paymentID,
    },
  })

  return {
    paymentID,
    bkashURL, // redirect user to this URL
  }
}

// ─── EXECUTE PAYMENT (after user completes on bKash) ─────────────────────────

export async function executeBkashPayment(paymentID: string) {
  const token = await getBkashToken()

  const res = await axios.post(
    `${BKASH_BASE}/tokenized/checkout/execute`,
    { paymentID },
    {
      headers: {
        'Content-Type': 'application/json',
        Authorization: token,
        'X-App-Key': APP_KEY,
      },
    }
  )

  const data = res.data

  if (data.transactionStatus !== 'Completed') {
    throw new Error(`bKash payment not completed: ${data.statusMessage}`)
  }

  // Update DB
  const payment = await prisma.payment.findFirst({
    where: { gatewayOrderId: paymentID },
  })

  if (payment) {
    await prisma.$transaction([
      prisma.payment.update({
        where: { id: payment.id },
        data: {
          status: 'PAID',
          gatewayTxnId: data.trxID,
          bkashTxnId: data.trxID,
          bkashNumber: data.customerMsisdn,
          paidAt: new Date(),
        },
      }),
      prisma.order.update({
        where: { id: payment.orderId },
        data: {
          paymentStatus: 'PAID',
          orderStatus: 'CONFIRMED',
        },
      }),
      prisma.trackingLog.create({
        data: {
          orderId: payment.orderId,
          status: 'CONFIRMED',
          message: `Payment confirmed via bKash. TxnID: ${data.trxID}`,
        },
      }),
    ])
  }

  return {
    success: true,
    trxID: data.trxID,
    customerMsisdn: data.customerMsisdn,
    amount: data.amount,
  }
}

// ─── QUERY PAYMENT STATUS ─────────────────────────────────────────────────────

export async function queryBkashPayment(paymentID: string) {
  const token = await getBkashToken()

  const res = await axios.post(
    `${BKASH_BASE}/tokenized/checkout/payment/status`,
    { paymentID },
    {
      headers: {
        'Content-Type': 'application/json',
        Authorization: token,
        'X-App-Key': APP_KEY,
      },
    }
  )

  return res.data
}

// ─── REFUND ───────────────────────────────────────────────────────────────────

export async function refundBkashPayment({
  paymentID,
  trxID,
  amount,
  reason = 'Customer requested refund',
}: {
  paymentID: string
  trxID: string
  amount: number
  reason?: string
}) {
  const token = await getBkashToken()

  const res = await axios.post(
    `${BKASH_BASE}/tokenized/checkout/payment/refund`,
    {
      paymentID,
      trxID,
      amount: amount.toFixed(2),
      currency: 'BDT',
      reason,
    },
    {
      headers: {
        'Content-Type': 'application/json',
        Authorization: token,
        'X-App-Key': APP_KEY,
      },
    }
  )

  return res.data
}
