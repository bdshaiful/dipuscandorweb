// src/lib/email.ts
import nodemailer from 'nodemailer'

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT || '587'),
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
})

function orderEmailTemplate(order: any): string {
  const items = order.items.map((item: any) => `
    <tr>
      <td style="padding:8px;border-bottom:1px solid #eee">${item.productName}</td>
      <td style="padding:8px;border-bottom:1px solid #eee;text-align:center">${item.quantity}</td>
      <td style="padding:8px;border-bottom:1px solid #eee;text-align:right">$${item.totalPrice.toFixed(2)}</td>
    </tr>`).join('')

  return `
<!DOCTYPE html>
<html>
<body style="font-family:'Segoe UI',sans-serif;background:#f4f4f4;margin:0;padding:20px">
  <div style="max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 20px rgba(0,0,0,.08)">
    <div style="background:#1A2340;color:#fff;padding:28px 32px">
      <h1 style="margin:0;font-size:24px">Dipus<span style="color:#E8A830">Candor</span></h1>
      <p style="margin:8px 0 0;opacity:.8;font-size:14px">Order Confirmation</p>
    </div>
    <div style="padding:32px">
      <h2 style="color:#1A2340;margin-top:0">Hi ${order.user.fullName}! 🎉</h2>
      <p style="color:#555">Thank you for your order. We've received it and will process it shortly.</p>
      <div style="background:#f8f8f8;border-radius:8px;padding:16px;margin:20px 0">
        <table style="width:100%;border-collapse:collapse">
          <tr style="font-weight:600;color:#1A2340">
            <td style="padding:8px">Order Number</td>
            <td style="padding:8px;text-align:right;color:#C8401A">${order.orderNumber}</td>
          </tr>
          <tr>
            <td style="padding:8px;color:#555">Payment Method</td>
            <td style="padding:8px;text-align:right">${order.paymentMethod.replace('_',' ')}</td>
          </tr>
          <tr>
            <td style="padding:8px;color:#555">Estimated Delivery</td>
            <td style="padding:8px;text-align:right">${new Date(order.estimatedDelivery).toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'})}</td>
          </tr>
        </table>
      </div>
      <h3 style="color:#1A2340">Order Items</h3>
      <table style="width:100%;border-collapse:collapse">
        <thead>
          <tr style="background:#f0f0f0">
            <th style="padding:10px;text-align:left">Product</th>
            <th style="padding:10px;text-align:center">Qty</th>
            <th style="padding:10px;text-align:right">Price</th>
          </tr>
        </thead>
        <tbody>${items}</tbody>
        <tfoot>
          <tr><td colspan="2" style="padding:10px;text-align:right;font-weight:600">Delivery</td><td style="padding:10px;text-align:right">${Number(order.deliveryCharge) === 0 ? '<span style="color:green">FREE</span>' : '$'+Number(order.deliveryCharge).toFixed(2)}</td></tr>
          ${Number(order.discountAmount) > 0 ? `<tr><td colspan="2" style="padding:10px;text-align:right;font-weight:600">Discount</td><td style="padding:10px;text-align:right;color:#C8401A">-$${Number(order.discountAmount).toFixed(2)}</td></tr>` : ''}
          <tr style="background:#1A2340;color:#fff"><td colspan="2" style="padding:12px;text-align:right;font-weight:700;font-size:16px">Total</td><td style="padding:12px;text-align:right;font-weight:700;font-size:16px">$${Number(order.grandTotal).toFixed(2)}</td></tr>
        </tfoot>
      </table>
      <div style="margin-top:24px;text-align:center">
        <a href="${process.env.NEXT_PUBLIC_APP_URL}/orders/${order.id}" style="background:#C8401A;color:#fff;padding:14px 32px;border-radius:25px;text-decoration:none;font-weight:600;display:inline-block">Track Your Order →</a>
      </div>
    </div>
    <div style="background:#f8f8f8;padding:20px 32px;text-align:center;color:#888;font-size:12px">
      <p>Questions? Contact us at <a href="mailto:support@dipuscandor.com" style="color:#C8401A">support@dipuscandor.com</a></p>
      <p style="margin-top:8px">© 2026 Dipus Candor. All rights reserved.</p>
    </div>
  </div>
</body>
</html>`
}

export async function sendOrderConfirmationEmail(order: any) {
  if (!order.user?.email) return

  await transporter.sendMail({
    from: `"${process.env.EMAIL_NAME}" <${process.env.EMAIL_FROM}>`,
    to: order.user.email,
    subject: `✅ Order Confirmed — ${order.orderNumber} | Dipus Candor`,
    html: orderEmailTemplate(order),
  })
}

export async function sendPasswordResetEmail(email: string, token: string) {
  const resetUrl = `${process.env.NEXT_PUBLIC_APP_URL}/reset-password?token=${token}`

  await transporter.sendMail({
    from: `"${process.env.EMAIL_NAME}" <${process.env.EMAIL_FROM}>`,
    to: email,
    subject: '🔐 Reset Your Password — Dipus Candor',
    html: `
      <div style="font-family:sans-serif;max-width:500px;margin:0 auto;padding:32px">
        <h2 style="color:#1A2340">Reset Your Password</h2>
        <p>Click the button below to reset your password. This link expires in 1 hour.</p>
        <a href="${resetUrl}" style="background:#C8401A;color:#fff;padding:14px 28px;border-radius:25px;text-decoration:none;font-weight:600;display:inline-block;margin:16px 0">Reset Password</a>
        <p style="color:#888;font-size:13px">If you didn't request this, ignore this email.</p>
      </div>`,
  })
}

export async function sendWelcomeEmail(name: string, email: string) {
  await transporter.sendMail({
    from: `"${process.env.EMAIL_NAME}" <${process.env.EMAIL_FROM}>`,
    to: email,
    subject: '🎉 Welcome to Dipus Candor!',
    html: `
      <div style="font-family:sans-serif;max-width:500px;margin:0 auto;padding:32px;text-align:center">
        <h1 style="color:#1A2340">Welcome, ${name}! 🎊</h1>
        <p>You're now part of the Dipus Candor family. Enjoy 500+ premium products with fast delivery.</p>
        <p style="font-size:18px;font-weight:700;color:#C8401A">Use code <span style="background:#FFF3E0;padding:4px 12px;border-radius:8px">WELCOME10</span> for 10% off your first order!</p>
        <a href="${process.env.NEXT_PUBLIC_APP_URL}" style="background:#1A2340;color:#fff;padding:14px 32px;border-radius:25px;text-decoration:none;font-weight:600;display:inline-block;margin-top:20px">Start Shopping →</a>
      </div>`,
  })
}
