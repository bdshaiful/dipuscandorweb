// src/lib/sms.ts
import twilio from 'twilio'

const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
)

const FROM = process.env.TWILIO_PHONE_NUMBER!

async function sendSMS(to: string, body: string) {
  if (!to || !process.env.TWILIO_ACCOUNT_SID) return
  
  // Ensure phone has country code
  const phone = to.startsWith('+') ? to : `+880${to.replace(/^0/, '')}`
  
  await client.messages.create({ from: FROM, to: phone, body })
}

export async function sendOrderSMS(order: any) {
  const phone = order.user?.phone || (order.shippingAddress as any)?.phone
  if (!phone) return

  await sendSMS(
    phone,
    `✅ Dipus Candor: Order ${order.orderNumber} confirmed! Total: $${Number(order.grandTotal).toFixed(2)}. Track at: ${process.env.NEXT_PUBLIC_APP_URL}/orders/${order.id}`
  )
}

export async function sendShippedSMS(phone: string, orderNumber: string, trackingId: string) {
  await sendSMS(
    phone,
    `🚚 Dipus Candor: Your order ${orderNumber} has been shipped! Tracking ID: ${trackingId}. Track live at ${process.env.NEXT_PUBLIC_APP_URL}/track/${trackingId}`
  )
}

export async function sendDeliveredSMS(phone: string, orderNumber: string) {
  await sendSMS(
    phone,
    `🎉 Dipus Candor: Order ${orderNumber} delivered! We hope you love it. Rate your experience: ${process.env.NEXT_PUBLIC_APP_URL}/review`
  )
}

export async function sendOTPSMS(phone: string, otp: string) {
  await sendSMS(
    phone,
    `Dipus Candor: Your OTP is ${otp}. Valid for 5 minutes. Do not share this with anyone.`
  )
}
