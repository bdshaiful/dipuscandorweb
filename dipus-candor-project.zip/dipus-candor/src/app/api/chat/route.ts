// src/app/api/chat/route.ts
// AI Chatbot powered by OpenAI GPT with product/order context (RAG-style)

import { NextRequest, NextResponse } from 'next/server'
import OpenAI from 'openai'
import prisma from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

const SYSTEM_PROMPT = `You are a helpful AI assistant for Dipus Candor, a modern e-commerce platform. 
Your name is "Dipus AI" and you are friendly, professional, and helpful.

STORE POLICIES:
- Free delivery on orders above $50
- Express delivery (1-2 days): $5.99
- Same-day delivery: $9.99
- 30-day return policy with free pickup
- Payment methods: Stripe (international), Razorpay (India/UPI), bKash (Bangladesh), Cash on Delivery
- Customer service hours: 9 AM – 9 PM (BD time), AI available 24/7
- Loyalty points: 1 point per $1 spent, 100 points = $1 discount

CAPABILITIES:
- Answer product questions
- Help with order tracking  
- Process return requests
- Apply promo codes
- Recommend products
- Explain payment options
- Provide shipping information

IMPORTANT:
- If a user seems frustrated, empathize and offer to escalate to human support
- For order-specific queries, use the user context provided
- Keep responses concise (2-4 sentences max unless more detail is needed)
- Use emojis sparingly to be friendly
- Always respond in the same language the user writes in
- If asked about specific real-time data you don't have, acknowledge and guide to the right page`

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    const body = await req.json()
    const { message, sessionToken, history = [] } = body

    if (!message?.trim()) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 })
    }

    // Build context for the user
    let userContext = ''

    if (session?.user?.id) {
      const userId = session.user.id

      // Fetch recent orders for context
      const recentOrders = await prisma.order.findMany({
        where: { userId },
        include: {
          items: { include: { product: { select: { name: true } } } },
          trackingLog: { orderBy: { createdAt: 'desc' }, take: 1 },
        },
        orderBy: { createdAt: 'desc' },
        take: 3,
      })

      if (recentOrders.length > 0) {
        userContext = `\n\nUSER CONTEXT (for ${session.user.name}):\n`
        recentOrders.forEach(order => {
          const latestStatus = order.trackingLog[0]?.status || order.orderStatus
          userContext += `- Order ${order.orderNumber}: ${latestStatus}, Total: $${order.grandTotal}\n`
        })
      }
    }

    // Build message history (last 10 messages to stay within token limits)
    const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [
      { role: 'system', content: SYSTEM_PROMPT + userContext },
      ...history.slice(-10).map((m: any) => ({
        role: m.role as 'user' | 'assistant',
        content: m.content,
      })),
      { role: 'user', content: message },
    ]

    // Check for intent to detect frustrated users
    const lowerMsg = message.toLowerCase()
    const isFrustrated =
      lowerMsg.includes('angry') ||
      lowerMsg.includes('terrible') ||
      lowerMsg.includes('worst') ||
      lowerMsg.includes('scam') ||
      lowerMsg.includes('refund now')

    const response = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      messages,
      max_tokens: 300,
      temperature: 0.7,
    })

    const reply = response.choices[0]?.message?.content || "I'm sorry, I couldn't process that. Please try again."

    // Persist chat session
    if (sessionToken) {
      await prisma.chatSession.upsert({
        where: { sessionToken },
        create: {
          sessionToken,
          userId: session?.user?.id || null,
          messages: [
            ...history,
            { role: 'user', content: message },
            { role: 'assistant', content: reply },
          ],
          sentiment: isFrustrated ? 'negative' : 'positive',
          escalated: isFrustrated,
        },
        update: {
          messages: [
            ...history,
            { role: 'user', content: message },
            { role: 'assistant', content: reply },
          ],
          sentiment: isFrustrated ? 'negative' : 'positive',
          escalated: isFrustrated,
        },
      })
    }

    return NextResponse.json({
      reply,
      escalate: isFrustrated,
      tokensUsed: response.usage?.total_tokens,
    })
  } catch (error: any) {
    console.error('[CHAT ERROR]', error)
    return NextResponse.json(
      { reply: "I'm having trouble connecting right now. Please try again in a moment or contact support@dipuscandor.com." },
      { status: 200 } // Always return 200 to show graceful fallback
    )
  }
}
