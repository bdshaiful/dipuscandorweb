// src/app/api/payment/create/route.ts
// Unified payment creation endpoint — handles Stripe, Razorpay, bKash, COD

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'
import { createStripePaymentIntent } from '@/lib/payments/stripe'
import { createRazorpayOrder } from '@/lib/payments/razorpay'
import { createBkashPayment } from '@/lib/payments/bkash'
import { z } from 'zod'

const createPaymentSchema = z.object({
  orderId: z.string().uuid(),
  method: z.enum(['STRIPE', 'RAZORPAY', 'BKASH', 'CASH_ON_DELIVERY']),
})

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { orderId, method } = createPaymentSchema.parse(body)

    // Fetch order and verify it belongs to this user
    const order = await prisma.order.findFirst({
      where: { id: orderId, userId: session.user.id },
      include: { user: true },
    })

    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }

    if (order.paymentStatus === 'PAID') {
      return NextResponse.json({ error: 'Order already paid' }, { status: 400 })
    }

    const amount = Number(order.grandTotal)

    switch (method) {
      // ── STRIPE ──────────────────────────────────────────────────────────────
      case 'STRIPE': {
        const { clientSecret, paymentIntentId } = await createStripePaymentIntent({
          orderId,
          amount,
          currency: 'usd',
          customerEmail: order.user.email,
          customerName: order.user.fullName,
          metadata: { orderNumber: order.orderNumber },
        })

        return NextResponse.json({
          gateway: 'stripe',
          clientSecret,
          paymentIntentId,
          publishableKey: process.env.NEXT_PUBLIC_STRIPE_KEY,
        })
      }

      // ── RAZORPAY ────────────────────────────────────────────────────────────
      case 'RAZORPAY': {
        const rzpData = await createRazorpayOrder({
          orderId,
          amount,
          currency: 'INR',
          receipt: order.orderNumber,
          notes: { orderNumber: order.orderNumber, userId: session.user.id },
        })

        return NextResponse.json({
          gateway: 'razorpay',
          ...rzpData,
          customerName: order.user.fullName,
          customerEmail: order.user.email,
          customerPhone: order.user.phone || '',
          description: `Payment for order ${order.orderNumber}`,
        })
      }

      // ── BKASH ───────────────────────────────────────────────────────────────
      case 'BKASH': {
        const callbackUrl = `${process.env.NEXT_PUBLIC_APP_URL}/api/payment/bkash/callback?orderId=${orderId}`

        const { paymentID, bkashURL } = await createBkashPayment({
          orderId,
          amount,
          callbackUrl,
          merchantInvoiceNumber: order.orderNumber,
        })

        return NextResponse.json({
          gateway: 'bkash',
          paymentID,
          bkashURL, // redirect user to this
        })
      }

      // ── CASH ON DELIVERY ────────────────────────────────────────────────────
      case 'CASH_ON_DELIVERY': {
        await prisma.$transaction([
          prisma.order.update({
            where: { id: orderId },
            data: {
              paymentMethod: 'CASH_ON_DELIVERY',
              orderStatus: 'CONFIRMED',
            },
          }),
          prisma.payment.create({
            data: {
              orderId,
              amount,
              currency: 'BDT',
              method: 'CASH_ON_DELIVERY',
              status: 'PENDING',
            },
          }),
          prisma.trackingLog.create({
            data: {
              orderId,
              status: 'CONFIRMED',
              message: 'Order confirmed. Cash will be collected on delivery.',
            },
          }),
        ])

        return NextResponse.json({
          gateway: 'cod',
          success: true,
          message: 'Order confirmed. Pay cash on delivery.',
        })
      }
    }
  } catch (error: any) {
    console.error('[PAYMENT CREATE ERROR]', error)
    if (error?.name === 'ZodError') {
      return NextResponse.json({ error: 'Invalid request data', details: error.errors }, { status: 400 })
    }
    return NextResponse.json({ error: 'Payment creation failed' }, { status: 500 })
  }
}
