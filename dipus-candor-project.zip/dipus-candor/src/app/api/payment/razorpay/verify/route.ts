// src/app/api/payment/razorpay/verify/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { confirmRazorpayPayment } from '@/lib/payments/razorpay'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { z } from 'zod'

const verifySchema = z.object({
  orderId: z.string(),
  razorpayOrderId: z.string(),
  razorpayPaymentId: z.string(),
  razorpaySignature: z.string(),
})

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const body = await req.json()
    const data = verifySchema.parse(body)
    const result = await confirmRazorpayPayment(data)
    return NextResponse.json(result)
  } catch (err: any) {
    console.error('[RAZORPAY VERIFY]', err.message)
    return NextResponse.json({ error: err.message }, { status: 400 })
  }
}
