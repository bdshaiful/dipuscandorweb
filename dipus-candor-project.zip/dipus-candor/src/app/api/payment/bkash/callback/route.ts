// src/app/api/payment/bkash/callback/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { executeBkashPayment, queryBkashPayment } from '@/lib/payments/bkash'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const paymentID = searchParams.get('paymentID')
  const status    = searchParams.get('status')
  const orderId   = searchParams.get('orderId')

  const appUrl = process.env.NEXT_PUBLIC_APP_URL

  if (!paymentID || !orderId) {
    return NextResponse.redirect(`${appUrl}/checkout?error=invalid_callback`)
  }

  if (status === 'cancel' || status === 'failure') {
    return NextResponse.redirect(`${appUrl}/checkout?error=bkash_${status}&orderId=${orderId}`)
  }

  try {
    const result = await executeBkashPayment(paymentID)
    return NextResponse.redirect(
      `${appUrl}/order-success?orderId=${orderId}&txnId=${result.trxID}&gateway=bkash`
    )
  } catch (err: any) {
    console.error('[BKASH CALLBACK ERROR]', err.message)
    // Query actual status before failing
    try {
      const status = await queryBkashPayment(paymentID)
      if (status.transactionStatus === 'Completed') {
        return NextResponse.redirect(`${appUrl}/order-success?orderId=${orderId}&gateway=bkash`)
      }
    } catch {}

    return NextResponse.redirect(`${appUrl}/checkout?error=bkash_failed&orderId=${orderId}`)
  }
}
