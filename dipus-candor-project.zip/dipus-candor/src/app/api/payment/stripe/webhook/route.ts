// src/app/api/payment/stripe/webhook/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { handleStripeWebhook } from '@/lib/payments/stripe'

export const config = { api: { bodyParser: false } }

export async function POST(req: NextRequest) {
  const payload = await req.arrayBuffer()
  const signature = req.headers.get('stripe-signature') || ''

  try {
    const result = await handleStripeWebhook(Buffer.from(payload), signature)
    return NextResponse.json(result)
  } catch (err: any) {
    console.error('[STRIPE WEBHOOK]', err.message)
    return NextResponse.json({ error: err.message }, { status: 400 })
  }
}
