// src/app/api/orders/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import prisma from '@/lib/prisma'
import { z } from 'zod'
import { sendOrderConfirmationEmail } from '@/lib/email'
import { sendOrderSMS } from '@/lib/sms'

const createOrderSchema = z.object({
  items: z.array(z.object({
    productId: z.string().uuid(),
    quantity: z.number().int().positive(),
    variantId: z.string().optional(),
  })).min(1),
  shippingAddress: z.object({
    fullName: z.string().min(2),
    phone: z.string().min(10),
    street: z.string().min(5),
    city: z.string().min(2),
    state: z.string().optional(),
    zipCode: z.string().min(4),
    country: z.string().default('Bangladesh'),
  }),
  paymentMethod: z.enum(['STRIPE', 'RAZORPAY', 'BKASH', 'CASH_ON_DELIVERY']),
  couponCode: z.string().optional(),
  notes: z.string().optional(),
})

function generateOrderNumber(): string {
  const timestamp = Date.now().toString(36).toUpperCase()
  const random = Math.random().toString(36).substring(2, 6).toUpperCase()
  return `DIP-${timestamp}-${random}`
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ error: 'Please login to place an order' }, { status: 401 })
    }

    const body = await req.json()
    const { items, shippingAddress, paymentMethod, couponCode, notes } =
      createOrderSchema.parse(body)

    // Fetch products and validate stock
    const productIds = items.map(i => i.productId)
    const products = await prisma.product.findMany({
      where: { id: { in: productIds }, isActive: true },
    })

    if (products.length !== productIds.length) {
      return NextResponse.json({ error: 'One or more products not found or unavailable' }, { status: 400 })
    }

    // Check stock
    for (const item of items) {
      const product = products.find(p => p.id === item.productId)!
      if (product.stockQuantity < item.quantity) {
        return NextResponse.json(
          { error: `Insufficient stock for "${product.name}". Available: ${product.stockQuantity}` },
          { status: 400 }
        )
      }
    }

    // Calculate totals
    let subtotal = 0
    const orderItems = items.map(item => {
      const product = products.find(p => p.id === item.productId)!
      const unitPrice = Number(product.price)
      const total = unitPrice * item.quantity
      subtotal += total
      return {
        productId: item.productId,
        productName: product.name,
        quantity: item.quantity,
        unitPrice,
        totalPrice: total,
      }
    })

    // Apply coupon
    let discountAmount = 0
    if (couponCode) {
      const coupon = await prisma.coupon.findFirst({
        where: {
          code: couponCode.toUpperCase(),
          isActive: true,
          OR: [{ expiresAt: null }, { expiresAt: { gte: new Date() } }],
          OR: [{ usageLimit: null }, { usedCount: { lt: prisma.coupon.fields.usageLimit } }],
        },
      })

      if (coupon) {
        const minOk = !coupon.minOrderAmount || subtotal >= Number(coupon.minOrderAmount)
        if (minOk) {
          if (coupon.type === 'PERCENTAGE') {
            discountAmount = (subtotal * Number(coupon.value)) / 100
            if (coupon.maxDiscount) discountAmount = Math.min(discountAmount, Number(coupon.maxDiscount))
          } else if (coupon.type === 'FIXED') {
            discountAmount = Math.min(Number(coupon.value), subtotal)
          }
          await prisma.coupon.update({ where: { id: coupon.id }, data: { usedCount: { increment: 1 } } })
        }
      }
    }

    const deliveryCharge = subtotal >= 50 ? 0 : 5.99
    const grandTotal = subtotal - discountAmount + deliveryCharge

    // Create order in transaction
    const order = await prisma.$transaction(async (tx) => {
      const newOrder = await tx.order.create({
        data: {
          userId: session.user.id,
          orderNumber: generateOrderNumber(),
          subtotal,
          discountAmount,
          deliveryCharge,
          taxAmount: 0,
          grandTotal,
          paymentMethod,
          paymentStatus: 'PENDING',
          orderStatus: 'PENDING',
          shippingAddress,
          couponCode: couponCode || null,
          notes: notes || null,
          estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // +3 days
          items: { create: orderItems },
        },
        include: { items: true, user: true },
      })

      // Decrement stock
      for (const item of items) {
        await tx.product.update({
          where: { id: item.productId },
          data: { stockQuantity: { decrement: item.quantity } },
        })
      }

      // Clear cart
      await tx.cartItem.deleteMany({ where: { userId: session.user.id } })

      // Initial tracking log
      await tx.trackingLog.create({
        data: {
          orderId: newOrder.id,
          status: 'PENDING',
          message: 'Order placed successfully. Awaiting payment confirmation.',
        },
      })

      return newOrder
    })

    // Send notifications (fire & forget)
    sendOrderConfirmationEmail(order).catch(console.error)
    sendOrderSMS(order).catch(console.error)

    return NextResponse.json({ orderId: order.id, orderNumber: order.orderNumber }, { status: 201 })
  } catch (error: any) {
    console.error('[ORDER CREATE]', error)
    if (error?.name === 'ZodError') {
      return NextResponse.json({ error: 'Invalid order data', details: error.errors }, { status: 400 })
    }
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 })
  }
}

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const page = parseInt(searchParams.get('page') || '1')
  const limit = parseInt(searchParams.get('limit') || '10')

  const [orders, total] = await Promise.all([
    prisma.order.findMany({
      where: { userId: session.user.id },
      include: {
        items: { include: { product: { select: { name: true, images: true } } } },
        payment: true,
        trackingLog: { orderBy: { createdAt: 'desc' }, take: 1 },
      },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit,
    }),
    prisma.order.count({ where: { userId: session.user.id } }),
  ])

  return NextResponse.json({ orders, total, page, totalPages: Math.ceil(total / limit) })
}
