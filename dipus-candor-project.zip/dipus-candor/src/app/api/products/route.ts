// src/app/api/products/route.ts
import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)

  const page        = parseInt(searchParams.get('page') || '1')
  const limit       = parseInt(searchParams.get('limit') || '12')
  const search      = searchParams.get('search') || ''
  const category    = searchParams.get('category') || ''
  const minPrice    = parseFloat(searchParams.get('minPrice') || '0')
  const maxPrice    = parseFloat(searchParams.get('maxPrice') || '999999')
  const sort        = searchParams.get('sort') || 'createdAt_desc'
  const featured    = searchParams.get('featured') === 'true'
  const bestSeller  = searchParams.get('bestSeller') === 'true'
  const newArrival  = searchParams.get('newArrival') === 'true'

  const skip = (page - 1) * limit

  // Build where clause
  const where: any = {
    isActive: true,
    price: { gte: minPrice, lte: maxPrice },
  }

  if (search) {
    where.OR = [
      { name: { contains: search, mode: 'insensitive' } },
      { description: { contains: search, mode: 'insensitive' } },
      { brand: { contains: search, mode: 'insensitive' } },
      { tags: { has: search } },
    ]
  }

  if (category) {
    where.category = { slug: category }
  }

  if (featured)   where.isFeatured   = true
  if (bestSeller) where.isBestSeller = true
  if (newArrival) where.isNewArrival = true

  // Build orderBy
  const [sortField, sortDir] = sort.split('_')
  const orderBy: any = { [sortField === 'price' ? 'price' : 'createdAt']: sortDir === 'asc' ? 'asc' : 'desc' }

  const [products, total] = await Promise.all([
    prisma.product.findMany({
      where,
      include: {
        category: { select: { name: true, slug: true } },
        reviews: { select: { rating: true } },
        _count: { select: { reviews: true } },
      },
      orderBy,
      skip,
      take: limit,
    }),
    prisma.product.count({ where }),
  ])

  // Compute average rating for each product
  const productsWithRating = products.map(p => ({
    ...p,
    avgRating: p.reviews.length
      ? p.reviews.reduce((sum, r) => sum + r.rating, 0) / p.reviews.length
      : 0,
    reviewCount: p._count.reviews,
    reviews: undefined,
    _count: undefined,
  }))

  return NextResponse.json({
    products: productsWithRating,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    },
  })
}
