// prisma/seed.ts
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding Dipus Candor database...')

  // ── Admin User ─────────────────────────────────────────────────────────────
  const adminPassword = await bcrypt.hash('Admin@123!', 12)
  const admin = await prisma.user.upsert({
    where: { email: 'admin@dipuscandor.com' },
    update: {},
    create: {
      fullName: 'Admin User',
      email: 'admin@dipuscandor.com',
      passwordHash: adminPassword,
      role: 'ADMIN',
      isVerified: true,
    },
  })
  console.log('✅ Admin created:', admin.email)

  // ── Test Customer ──────────────────────────────────────────────────────────
  const customerPassword = await bcrypt.hash('Customer@123', 10)
  await prisma.user.upsert({
    where: { email: 'customer@example.com' },
    update: {},
    create: {
      fullName: 'Test Customer',
      email: 'customer@example.com',
      phone: '01700000001',
      passwordHash: customerPassword,
      role: 'CUSTOMER',
      isVerified: true,
    },
  })

  // ── Categories ─────────────────────────────────────────────────────────────
  const categories = [
    { name: 'Fashion', slug: 'fashion', description: 'Clothing, accessories, and more' },
    { name: 'Electronics', slug: 'electronics', description: 'Gadgets and tech products' },
    { name: 'Beauty', slug: 'beauty', description: 'Skincare, makeup, and wellness' },
    { name: 'Home & Living', slug: 'home', description: 'Furniture, decor, and appliances' },
    { name: 'Sports', slug: 'sports', description: 'Fitness equipment and sportswear' },
    { name: 'Books', slug: 'books', description: 'Books, stationery, and learning' },
  ]

  const catMap: Record<string, string> = {}
  for (const cat of categories) {
    const c = await prisma.category.upsert({
      where: { slug: cat.slug },
      update: {},
      create: { ...cat, isActive: true },
    })
    catMap[cat.slug] = c.id
    console.log('✅ Category:', cat.name)
  }

  // ── Products ───────────────────────────────────────────────────────────────
  const products = [
    {
      name: 'Premium Red Midi Dress',
      slug: 'premium-red-midi-dress',
      description: 'Elegant midi dress perfect for parties and formal gatherings. Made with premium fabric.',
      price: 42.99, comparePrice: 71.99, stockQuantity: 150,
      categoryId: catMap['fashion'], brand: 'StyleHub',
      images: ['https://example.com/dress1.jpg'], isFeatured: true, isBestSeller: true,
      tags: ['dress', 'red', 'party', 'fashion'],
    },
    {
      name: 'Wireless Earbuds Pro X',
      slug: 'wireless-earbuds-pro-x',
      description: 'Crystal clear audio with 30hr battery, active noise cancellation, and premium build.',
      price: 89.99, comparePrice: 129.99, stockQuantity: 80,
      categoryId: catMap['electronics'], brand: 'SoundMax',
      images: ['https://example.com/earbuds.jpg'], isFeatured: true, isNewArrival: true,
      tags: ['earbuds', 'wireless', 'audio', 'noise-cancellation'],
    },
    {
      name: 'Vitamin C Glow Serum',
      slug: 'vitamin-c-glow-serum',
      description: 'Dermatologist-tested brightening serum. Cruelty-free, vegan formula for all skin types.',
      price: 34.99, comparePrice: 49.99, stockQuantity: 200,
      categoryId: catMap['beauty'], brand: 'GlowLab',
      images: ['https://example.com/serum.jpg'], isFeatured: true, isBestSeller: true,
      tags: ['serum', 'vitamin-c', 'skincare', 'glow'],
    },
    {
      name: 'Smart RGB LED Lamp',
      slug: 'smart-rgb-led-lamp',
      description: 'App-controlled 16M color smart lamp. Voice assistant compatible, energy-efficient.',
      price: 24.99, comparePrice: 39.99, stockQuantity: 120,
      categoryId: catMap['home'], brand: 'LumiHome',
      images: ['https://example.com/lamp.jpg'],
      tags: ['lamp', 'smart', 'RGB', 'home'],
    },
    {
      name: 'Pro Running Sneakers',
      slug: 'pro-running-sneakers',
      description: 'Lightweight, breathable mesh upper with responsive cushioning for peak performance.',
      price: 64.99, comparePrice: 99.99, stockQuantity: 90,
      categoryId: catMap['sports'], brand: 'SpeedFit',
      images: ['https://example.com/sneakers.jpg'], isFeatured: true,
      tags: ['sneakers', 'running', 'sports', 'shoes'],
    },
    {
      name: 'Smart Watch Series 5',
      slug: 'smart-watch-series-5',
      description: '7-day battery, GPS, health monitoring, 50m water resistance. All-day wearable.',
      price: 149.99, comparePrice: 199.99, stockQuantity: 60,
      categoryId: catMap['electronics'], brand: 'TechWear',
      images: ['https://example.com/watch.jpg'], isNewArrival: true, isFeatured: true,
      tags: ['smartwatch', 'GPS', 'health', 'wearable'],
    },
    {
      name: 'Luxury Silk Scarf',
      slug: 'luxury-silk-scarf',
      description: 'Pure silk with stunning floral print. Versatile accessory for all seasons.',
      price: 19.99, comparePrice: 34.99, stockQuantity: 200,
      categoryId: catMap['fashion'], brand: 'EleganceWear',
      images: ['https://example.com/scarf.jpg'],
      tags: ['scarf', 'silk', 'accessories', 'fashion'],
    },
    {
      name: 'Premium Yoga Mat',
      slug: 'premium-yoga-mat',
      description: 'Eco-friendly 6mm non-slip mat with carry strap. Perfect for yoga, pilates, fitness.',
      price: 29.99, comparePrice: 44.99, stockQuantity: 150,
      categoryId: catMap['sports'], brand: 'ZenFit',
      images: ['https://example.com/yogamat.jpg'], isBestSeller: true,
      tags: ['yoga', 'mat', 'fitness', 'eco-friendly'],
    },
  ]

  for (const product of products) {
    await prisma.product.upsert({
      where: { slug: product.slug },
      update: {},
      create: { ...product, isActive: true, weightKg: 0.5 },
    })
    console.log('✅ Product:', product.name)
  }

  // ── Coupons ────────────────────────────────────────────────────────────────
  await prisma.coupon.createMany({
    skipDuplicates: true,
    data: [
      { code: 'WELCOME10', type: 'PERCENTAGE', value: 10, usageLimit: 1000, isActive: true },
      { code: 'DIPUS15', type: 'PERCENTAGE', value: 15, usageLimit: 500, isActive: true },
      { code: 'SAVE50', type: 'FIXED', value: 50, minOrderAmount: 200, usageLimit: 100, isActive: true },
      { code: 'FREESHIP', type: 'FREE_SHIPPING', value: 0, usageLimit: 200, isActive: true },
    ],
  })
  console.log('✅ Coupons created')

  // ── Flash Sale ─────────────────────────────────────────────────────────────
  const flashSale = await prisma.flashSale.create({
    data: {
      title: 'Weekend Mega Sale',
      startsAt: new Date(),
      endsAt: new Date(Date.now() + 48 * 60 * 60 * 1000), // 48 hours
      isActive: true,
    },
  })
  console.log('✅ Flash sale created:', flashSale.title)

  console.log('\n🎉 Database seeded successfully!')
  console.log('\n📧 Admin Login:')
  console.log('   Email: admin@dipuscandor.com')
  console.log('   Password: Admin@123!')
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
