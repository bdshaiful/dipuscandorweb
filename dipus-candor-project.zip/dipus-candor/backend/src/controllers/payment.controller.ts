import { Request, Response, NextFunction } from 'express';
import Stripe from 'stripe';
import { query, transaction } from '../config/database';
import { AppError } from '../utils/AppError';
import { sendEmail } from '../services/email.service';
import { sendSMS } from '../services/sms.service';
import { logger } from '../utils/logger';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

// ============================================================
// STRIPE - Create Payment Intent
// ============================================================

export async function createStripePaymentIntent(req: Request, res: Response, next: NextFunction) {
  try {
    const { orderId } = req.body;
    const userId = (req as any).user.userId;

    const orderResult = await query(
      `SELECT id, order_number, grand_total, payment_status, user_id
       FROM orders WHERE id = $1 AND user_id = $2`,
      [orderId, userId]
    );

    if (orderResult.rowCount === 0) throw new AppError('Order not found', 404);
    const order = orderResult.rows[0];

    if (order.payment_status === 'paid') throw new AppError('Order already paid', 400);

    // Convert to smallest currency unit (paisa for BDT)
    const amountInCents = Math.round(parseFloat(order.grand_total) * 100);

    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountInCents,
      currency: 'bdt',
      metadata: {
        orderId: order.id,
        orderNumber: order.order_number,
        userId,
      },
      description: `Dipus Candor - Order ${order.order_number}`,
    });

    // Store intent ID
    await query(
      'UPDATE orders SET payment_transaction_id = $1 WHERE id = $2',
      [paymentIntent.id, orderId]
    );

    res.json({
      success: true,
      data: {
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id,
        amount: order.grand_total,
        publishableKey: process.env.STRIPE_PUBLISHABLE_KEY,
      },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// STRIPE - Webhook Handler
// ============================================================

export async function stripeWebhook(req: Request, res: Response, next: NextFunction) {
  const sig = req.headers['stripe-signature'] as string;

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err: any) {
    logger.error('Stripe webhook signature verification failed:', err.message);
    return res.status(400).json({ error: 'Invalid webhook signature' });
  }

  try {
    switch (event.type) {
      case 'payment_intent.succeeded': {
        const intent = event.data.object as Stripe.PaymentIntent;
        await handlePaymentSuccess(intent.metadata.orderId, intent.id, 'stripe');
        break;
      }

      case 'payment_intent.payment_failed': {
        const intent = event.data.object as Stripe.PaymentIntent;
        await query(
          `UPDATE orders SET payment_status = 'failed', status = 'cancelled' WHERE id = $1`,
          [intent.metadata.orderId]
        );
        break;
      }

      case 'charge.dispute.created': {
        logger.warn('Charge dispute created:', event.data.object);
        break;
      }
    }

    res.json({ received: true });
  } catch (error) {
    logger.error('Webhook processing error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
}

// ============================================================
// BKASH - Initialize Payment
// ============================================================

let bkashToken: { token: string; expiresAt: Date } | null = null;

async function getBkashToken(): Promise<string> {
  if (bkashToken && bkashToken.expiresAt > new Date()) {
    return bkashToken.token;
  }

  const response = await fetch(`${process.env.BKASH_BASE_URL}/tokenized/checkout/token/grant`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      username: process.env.BKASH_USERNAME!,
      password: process.env.BKASH_PASSWORD!,
    },
    body: JSON.stringify({
      app_key: process.env.BKASH_APP_KEY,
      app_secret: process.env.BKASH_APP_SECRET,
    }),
  });

  const data = await response.json();
  if (!data.id_token) throw new AppError('Failed to get bKash token', 500);

  bkashToken = {
    token: data.id_token,
    expiresAt: new Date(Date.now() + (data.expires_in - 60) * 1000),
  };

  return bkashToken.token;
}

export async function initiateBkashPayment(req: Request, res: Response, next: NextFunction) {
  try {
    const { orderId } = req.body;
    const userId = (req as any).user.userId;

    const orderResult = await query(
      'SELECT id, order_number, grand_total FROM orders WHERE id = $1 AND user_id = $2',
      [orderId, userId]
    );

    if (orderResult.rowCount === 0) throw new AppError('Order not found', 404);
    const order = orderResult.rows[0];

    const token = await getBkashToken();

    const response = await fetch(`${process.env.BKASH_BASE_URL}/tokenized/checkout/create`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Authorization: token,
        'X-App-Key': process.env.BKASH_APP_KEY!,
      },
      body: JSON.stringify({
        mode: '0011',
        payerReference: userId,
        callbackURL: `${process.env.API_URL}/api/v1/payments/bkash/callback`,
        amount: order.grand_total.toString(),
        currency: 'BDT',
        intent: 'sale',
        merchantInvoiceNumber: order.order_number,
      }),
    });

    const data = await response.json();

    if (data.statusCode !== '0000') {
      throw new AppError(`bKash error: ${data.statusMessage}`, 400);
    }

    // Store bKash payment ID
    await query(
      `UPDATE orders SET payment_transaction_id = $1,
       payment_gateway_data = $2 WHERE id = $3`,
      [data.paymentID, JSON.stringify({ bkash: data }), orderId]
    );

    res.json({
      success: true,
      data: {
        paymentID: data.paymentID,
        bkashURL: data.bkashURL, // Redirect user here
        amount: order.grand_total,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function bkashCallback(req: Request, res: Response, next: NextFunction) {
  try {
    const { paymentID, status } = req.query;

    if (status === 'cancel' || status === 'failure') {
      return res.redirect(
        `${process.env.APP_URL}/payment/failed?paymentID=${paymentID}`
      );
    }

    const token = await getBkashToken();

    // Execute payment
    const response = await fetch(`${process.env.BKASH_BASE_URL}/tokenized/checkout/execute`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Authorization: token,
        'X-App-Key': process.env.BKASH_APP_KEY!,
      },
      body: JSON.stringify({ paymentID }),
    });

    const data = await response.json();

    const orderResult = await query(
      `SELECT id, order_number FROM orders
       WHERE payment_transaction_id = $1`,
      [paymentID]
    );

    if (orderResult.rowCount === 0) {
      return res.redirect(`${process.env.APP_URL}/payment/failed`);
    }

    const order = orderResult.rows[0];

    if (data.statusCode === '0000' && data.transactionStatus === 'Completed') {
      await handlePaymentSuccess(order.id, data.trxID, 'bkash');
      return res.redirect(
        `${process.env.APP_URL}/order/success?orderId=${order.id}`
      );
    } else {
      await query(
        `UPDATE orders SET payment_status = 'failed' WHERE id = $1`,
        [order.id]
      );
      return res.redirect(
        `${process.env.APP_URL}/payment/failed?orderId=${order.id}`
      );
    }
  } catch (error) {
    next(error);
  }
}

// ============================================================
// COD - Cash on Delivery
// ============================================================

export async function confirmCODOrder(req: Request, res: Response, next: NextFunction) {
  try {
    const { orderId } = req.body;
    const userId = (req as any).user.userId;

    // Check COD limit
    const settingResult = await query(
      "SELECT value FROM site_settings WHERE key = 'max_cod_amount'"
    );
    const maxCOD = parseFloat(settingResult.rows[0]?.value || '10000');

    const orderResult = await query(
      `SELECT id, order_number, grand_total, user_id
       FROM orders WHERE id = $1 AND user_id = $2 AND payment_method = 'cod'`,
      [orderId, userId]
    );

    if (orderResult.rowCount === 0) throw new AppError('Order not found', 404);
    const order = orderResult.rows[0];

    if (parseFloat(order.grand_total) > maxCOD) {
      throw new AppError(`COD not available for orders above ৳${maxCOD}`, 400);
    }

    await query(
      `UPDATE orders SET status = 'confirmed', payment_status = 'pending'
       WHERE id = $1`,
      [order.id]
    );

    await sendOrderConfirmationNotification(order.id);

    res.json({
      success: true,
      message: 'Order confirmed! You will pay on delivery.',
      data: { orderId: order.id, orderNumber: order.order_number },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// REFUND
// ============================================================

export async function processRefund(req: Request, res: Response, next: NextFunction) {
  try {
    const { orderId, reason } = req.body;
    const adminId = (req as any).user.userId;

    const orderResult = await query(
      `SELECT id, order_number, grand_total, payment_method,
       payment_transaction_id, payment_status, user_id
       FROM orders WHERE id = $1`,
      [orderId]
    );

    if (orderResult.rowCount === 0) throw new AppError('Order not found', 404);
    const order = orderResult.rows[0];

    if (!['paid'].includes(order.payment_status)) {
      throw new AppError('Order is not eligible for refund', 400);
    }

    let refundResult = { id: null as any };

    if (order.payment_method === 'stripe' && order.payment_transaction_id) {
      const stripeRefund = await stripe.refunds.create({
        payment_intent: order.payment_transaction_id,
        reason: 'requested_by_customer',
      });
      refundResult = stripeRefund;
    }

    await query(
      `UPDATE orders SET payment_status = 'refunded', status = 'returned',
       cancel_reason = $1 WHERE id = $2`,
      [reason, orderId]
    );

    // Log admin action
    await query(
      `INSERT INTO admin_logs (admin_id, action, target_type, target_id, new_values)
       VALUES ($1, 'process_refund', 'order', $2, $3)`,
      [adminId, orderId, JSON.stringify({ reason, refundId: refundResult.id })]
    );

    res.json({ success: true, message: 'Refund processed successfully' });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// HELPER FUNCTIONS
// ============================================================

async function handlePaymentSuccess(orderId: string, transactionId: string, gateway: string) {
  await transaction(async (client) => {
    // Update order
    await client.query(
      `UPDATE orders SET
         payment_status = 'paid',
         status = 'confirmed',
         payment_gateway_data = payment_gateway_data || $1::jsonb
       WHERE id = $2`,
      [JSON.stringify({ gateway, transactionId, paidAt: new Date() }), orderId]
    );

    // Log status history
    await client.query(
      `INSERT INTO order_status_history (order_id, status, note)
       VALUES ($1, 'confirmed', $2)`,
      [orderId, `Payment received via ${gateway}. Transaction: ${transactionId}`]
    );
  });

  await sendOrderConfirmationNotification(orderId);
  logger.info(`Payment success: Order ${orderId} via ${gateway}`);
}

async function sendOrderConfirmationNotification(orderId: string) {
  try {
    const result = await query(
      `SELECT o.order_number, o.grand_total, u.email, u.phone, u.full_name
       FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = $1`,
      [orderId]
    );

    if (result.rowCount === 0) return;
    const { order_number, grand_total, email, phone, full_name } = result.rows[0];

    if (email) {
      await sendEmail({
        to: email,
        subject: `Order Confirmed - ${order_number}`,
        template: 'order-confirmation',
        data: { name: full_name, orderNumber: order_number, total: grand_total },
      });
    }

    if (phone) {
      await sendSMS(
        phone,
        `Hi ${full_name}! Your Dipus Candor order ${order_number} is confirmed. Total: ৳${grand_total}. Track: dipuscandor.com/orders`
      );
    }
  } catch (error) {
    logger.error('Failed to send order confirmation:', error);
  }
}
