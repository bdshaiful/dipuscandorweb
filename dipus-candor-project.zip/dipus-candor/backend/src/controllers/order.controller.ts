import { Request, Response, NextFunction } from 'express';
import { query, transaction } from '../config/database';
import { AppError } from '../utils/AppError';

// ============================================================
// CREATE ORDER (Checkout)
// ============================================================

export async function createOrder(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = (req as any).user?.userId;
    const {
      cartId, shippingAddressId, billingAddress,
      paymentMethod, couponCode, giftWrapping,
      giftMessage, notes, deliveryZoneId,
    } = req.body;

    const order = await transaction(async (client) => {
      // Get cart items
      const cartResult = await client.query(
        `SELECT ci.*, p.name, p.price as product_price, p.stock_quantity,
           p.images, pv.variant_name, pv.price as variant_price
         FROM cart_items ci
         JOIN products p ON ci.product_id = p.id
         LEFT JOIN product_variants pv ON ci.variant_id = pv.id
         WHERE ci.cart_id = $1`,
        [cartId]
      );

      if (cartResult.rowCount === 0) throw new AppError('Cart is empty', 400);

      // Check stock
      for (const item of cartResult.rows) {
        const price = item.variant_price || item.product_price;
        if (item.stock_quantity < item.quantity) {
          throw new AppError(`Insufficient stock for: ${item.name}`, 400);
        }
      }

      // Get shipping address
      let shippingAddress;
      if (shippingAddressId) {
        const addrResult = await client.query(
          'SELECT * FROM user_addresses WHERE id = $1 AND user_id = $2',
          [shippingAddressId, userId]
        );
        if (addrResult.rowCount === 0) throw new AppError('Address not found', 404);
        shippingAddress = addrResult.rows[0];
      } else {
        shippingAddress = req.body.shippingAddress;
      }

      // Calculate totals
      let subtotal = 0;
      const items = cartResult.rows.map(item => {
        const price = parseFloat(item.variant_price || item.product_price);
        const total = price * item.quantity;
        subtotal += total;
        return {
          product_id: item.product_id,
          variant_id: item.variant_id,
          product_name: item.name,
          variant_name: item.variant_name,
          product_image: item.images?.[0]?.url,
          quantity: item.quantity,
          unit_price: price,
          total_price: total,
        };
      });

      // Apply coupon
      let discountAmount = 0;
      let appliedCoupon = null;
      if (couponCode) {
        const couponResult = await client.query(
          `SELECT * FROM coupons
           WHERE code = $1 AND is_active = TRUE
           AND (expires_at IS NULL OR expires_at > NOW())
           AND (usage_limit IS NULL OR used_count < usage_limit)
           AND min_order_amount <= $2`,
          [couponCode, subtotal]
        );

        if (couponResult.rowCount > 0) {
          const coupon = couponResult.rows[0];

          // Check per-user limit
          if (userId) {
            const usageResult = await client.query(
              `SELECT COUNT(*) FROM coupon_usage WHERE coupon_id = $1 AND user_id = $2`,
              [coupon.id, userId]
            );
            const userUsage = parseInt(usageResult.rows[0].count);
            if (userUsage >= (coupon.per_user_limit || 1)) {
              throw new AppError('You have already used this coupon', 400);
            }
          }

          if (coupon.discount_type === 'percentage') {
            discountAmount = subtotal * (coupon.discount_value / 100);
            if (coupon.max_discount_amount) {
              discountAmount = Math.min(discountAmount, coupon.max_discount_amount);
            }
          } else if (coupon.discount_type === 'fixed') {
            discountAmount = Math.min(coupon.discount_value, subtotal);
          }

          appliedCoupon = coupon;
        }
      }

      // Get delivery charge
      let deliveryCharge = 0;
      if (deliveryZoneId) {
        const zoneResult = await client.query(
          'SELECT * FROM delivery_zones WHERE id = $1',
          [deliveryZoneId]
        );
        if (zoneResult.rowCount > 0) {
          const zone = zoneResult.rows[0];
          if (!zone.free_delivery_above || subtotal < zone.free_delivery_above) {
            deliveryCharge = parseFloat(zone.base_charge);
          }
        }
      }

      // Gift wrapping fee
      const giftWrappingFee = giftWrapping ? 50 : 0;

      const grandTotal = subtotal - discountAmount + deliveryCharge + giftWrappingFee;

      // Create order
      const orderResult = await client.query(
        `INSERT INTO orders (
           user_id, subtotal, discount_amount, delivery_charge,
           grand_total, payment_method, payment_status, shipping_address,
           coupon_code, gift_wrapping, gift_message, notes
         ) VALUES ($1,$2,$3,$4,$5,$6,'pending',$7,$8,$9,$10,$11)
         RETURNING *`,
        [
          userId || null, subtotal, discountAmount, deliveryCharge,
          grandTotal, paymentMethod, JSON.stringify(shippingAddress),
          couponCode || null, giftWrapping || false, giftMessage || null, notes || null,
        ]
      );

      const newOrder = orderResult.rows[0];

      // Create order items
      for (const item of items) {
        await client.query(
          `INSERT INTO order_items (
             order_id, product_id, variant_id, product_name, variant_name,
             product_image, quantity, unit_price, total_price
           ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
          [
            newOrder.id, item.product_id, item.variant_id,
            item.product_name, item.variant_name, item.product_image,
            item.quantity, item.unit_price, item.total_price,
          ]
        );

        // Deduct stock
        await client.query(
          `UPDATE products SET stock_quantity = stock_quantity - $1,
           sold_count = sold_count + $1 WHERE id = $2`,
          [item.quantity, item.product_id]
        );

        if (item.variant_id) {
          await client.query(
            `UPDATE product_variants SET stock_quantity = stock_quantity - $1
             WHERE id = $2`,
            [item.quantity, item.variant_id]
          );
        }
      }

      // Log order status history
      await client.query(
        `INSERT INTO order_status_history (order_id, status, note)
         VALUES ($1, 'pending', 'Order placed')`,
        [newOrder.id]
      );

      // Update coupon usage
      if (appliedCoupon) {
        await client.query(
          `UPDATE coupons SET used_count = used_count + 1 WHERE id = $1`,
          [appliedCoupon.id]
        );
        await client.query(
          `INSERT INTO coupon_usage (coupon_id, user_id, order_id, discount_applied)
           VALUES ($1, $2, $3, $4)`,
          [appliedCoupon.id, userId || null, newOrder.id, discountAmount]
        );
      }

      // Clear cart
      await client.query('DELETE FROM cart_items WHERE cart_id = $1', [cartId]);

      return newOrder;
    });

    res.status(201).json({
      success: true,
      message: 'Order created successfully',
      data: {
        order: {
          id: order.id,
          orderNumber: order.order_number,
          grandTotal: order.grand_total,
          paymentMethod: order.payment_method,
          status: order.status,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// GET USER ORDERS
// ============================================================

export async function getUserOrders(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = (req as any).user.userId;
    const { page = '1', limit = '10', status } = req.query as Record<string, string>;

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const offset = (pageNum - 1) * limitNum;

    let whereClause = 'o.user_id = $1';
    let params: any[] = [userId];

    if (status) {
      whereClause += ` AND o.status = $2`;
      params.push(status);
    }

    const result = await query(
      `SELECT
         o.id, o.order_number, o.status, o.payment_status,
         o.grand_total, o.delivery_charge, o.discount_amount,
         o.payment_method, o.created_at, o.estimated_delivery,
         o.tracking_id,
         json_agg(json_build_object(
           'product_name', oi.product_name,
           'quantity', oi.quantity,
           'unit_price', oi.unit_price,
           'product_image', oi.product_image
         )) as items,
         COUNT(*) OVER() as total_count
       FROM orders o
       JOIN order_items oi ON o.id = oi.order_id
       WHERE ${whereClause}
       GROUP BY o.id
       ORDER BY o.created_at DESC
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
      [...params, limitNum, offset]
    );

    const total = result.rowCount > 0 ? parseInt(result.rows[0].total_count) : 0;

    res.json({
      success: true,
      data: {
        orders: result.rows,
        pagination: { page: pageNum, limit: limitNum, total, totalPages: Math.ceil(total / limitNum) },
      },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// GET ORDER DETAILS
// ============================================================

export async function getOrderDetails(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const userId = (req as any).user.userId;
    const userRole = (req as any).user.role;

    let whereClause = 'o.id = $1';
    let params: any[] = [id];

    if (userRole !== 'admin' && userRole !== 'super_admin') {
      whereClause += ' AND o.user_id = $2';
      params.push(userId);
    }

    const orderResult = await query(
      `SELECT o.*, u.full_name as customer_name, u.email as customer_email, u.phone as customer_phone
       FROM orders o
       LEFT JOIN users u ON o.user_id = u.id
       WHERE ${whereClause}`,
      params
    );

    if (orderResult.rowCount === 0) throw new AppError('Order not found', 404);
    const order = orderResult.rows[0];

    const [itemsResult, historyResult] = await Promise.all([
      query(
        `SELECT oi.*, p.slug as product_slug
         FROM order_items oi
         LEFT JOIN products p ON oi.product_id = p.id
         WHERE oi.order_id = $1`,
        [id]
      ),
      query(
        `SELECT osh.*, u.full_name as updated_by_name
         FROM order_status_history osh
         LEFT JOIN users u ON osh.updated_by = u.id
         WHERE osh.order_id = $1
         ORDER BY osh.created_at ASC`,
        [id]
      ),
    ]);

    res.json({
      success: true,
      data: {
        order: { ...order, items: itemsResult.rows, statusHistory: historyResult.rows },
      },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// CANCEL ORDER
// ============================================================

export async function cancelOrder(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    const userId = (req as any).user.userId;

    const orderResult = await query(
      `SELECT id, status, payment_status, created_at, user_id
       FROM orders WHERE id = $1`,
      [id]
    );

    if (orderResult.rowCount === 0) throw new AppError('Order not found', 404);
    const order = orderResult.rows[0];

    if (order.user_id !== userId) throw new AppError('Not authorized', 403);

    const cancelableStatuses = ['pending', 'confirmed'];
    if (!cancelableStatuses.includes(order.status)) {
      throw new AppError('Order cannot be cancelled at this stage. Please contact support.', 400);
    }

    // Check 2-hour window for COD orders after confirmation
    const hoursSinceOrder = (Date.now() - new Date(order.created_at).getTime()) / 3600000;
    if (order.status === 'confirmed' && hoursSinceOrder > 2) {
      throw new AppError('Cancellation window has expired (2 hours). Please contact support.', 400);
    }

    await transaction(async (client) => {
      await client.query(
        `UPDATE orders SET status = 'cancelled', cancel_reason = $1, cancelled_at = NOW()
         WHERE id = $2`,
        [reason || 'Customer requested cancellation', id]
      );

      await client.query(
        `INSERT INTO order_status_history (order_id, status, note, updated_by)
         VALUES ($1, 'cancelled', $2, $3)`,
        [id, reason || 'Customer requested cancellation', userId]
      );

      // Restore stock
      const items = await client.query(
        'SELECT product_id, variant_id, quantity FROM order_items WHERE order_id = $1',
        [id]
      );

      for (const item of items.rows) {
        await client.query(
          `UPDATE products SET stock_quantity = stock_quantity + $1,
           sold_count = GREATEST(sold_count - $1, 0) WHERE id = $2`,
          [item.quantity, item.product_id]
        );
      }
    });

    res.json({ success: true, message: 'Order cancelled successfully' });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// ADMIN - UPDATE ORDER STATUS
// ============================================================

export async function updateOrderStatus(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const { status, note, trackingId, trackingUrl, estimatedDelivery } = req.body;
    const adminId = (req as any).user.userId;

    const updates: string[] = [`status = $2`];
    const params: any[] = [id, status];

    if (trackingId) { updates.push(`tracking_id = $${params.length + 1}`); params.push(trackingId); }
    if (trackingUrl) { updates.push(`tracking_url = $${params.length + 1}`); params.push(trackingUrl); }
    if (estimatedDelivery) { updates.push(`estimated_delivery = $${params.length + 1}`); params.push(estimatedDelivery); }
    if (status === 'delivered') { updates.push(`delivered_at = NOW()`); }

    await query(
      `UPDATE orders SET ${updates.join(', ')}, updated_at = NOW() WHERE id = $1`,
      params
    );

    await query(
      `INSERT INTO order_status_history (order_id, status, note, updated_by)
       VALUES ($1, $2, $3, $4)`,
      [id, status, note || null, adminId]
    );

    res.json({ success: true, message: 'Order status updated' });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// ADMIN - GET ALL ORDERS
// ============================================================

export async function adminGetOrders(req: Request, res: Response, next: NextFunction) {
  try {
    const {
      page = '1', limit = '20', status, paymentStatus,
      search, dateFrom, dateTo,
    } = req.query as Record<string, string>;

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const offset = (pageNum - 1) * limitNum;

    let conditions: string[] = [];
    let params: any[] = [];
    let i = 1;

    if (status) { conditions.push(`o.status = $${i++}`); params.push(status); }
    if (paymentStatus) { conditions.push(`o.payment_status = $${i++}`); params.push(paymentStatus); }
    if (search) {
      conditions.push(`(o.order_number ILIKE $${i} OR u.email ILIKE $${i} OR u.phone ILIKE $${i})`);
      params.push(`%${search}%`); i++;
    }
    if (dateFrom) { conditions.push(`o.created_at >= $${i++}`); params.push(dateFrom); }
    if (dateTo) { conditions.push(`o.created_at <= $${i++}`); params.push(dateTo); }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const result = await query(
      `SELECT o.id, o.order_number, o.status, o.payment_status, o.payment_method,
         o.grand_total, o.created_at, o.estimated_delivery,
         u.full_name as customer_name, u.email as customer_email, u.phone as customer_phone,
         COUNT(*) OVER() as total_count
       FROM orders o
       LEFT JOIN users u ON o.user_id = u.id
       ${whereClause}
       ORDER BY o.created_at DESC
       LIMIT $${i} OFFSET $${i + 1}`,
      [...params, limitNum, offset]
    );

    const total = result.rowCount > 0 ? parseInt(result.rows[0].total_count) : 0;

    res.json({
      success: true,
      data: {
        orders: result.rows,
        pagination: { page: pageNum, limit: limitNum, total, totalPages: Math.ceil(total / limitNum) },
      },
    });
  } catch (error) {
    next(error);
  }
}
