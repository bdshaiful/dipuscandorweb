import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';
import { query, transaction } from '../config/database';
import { AppError } from '../utils/AppError';
import { sendEmail } from '../services/email.service';
import { sendSMS } from '../services/sms.service';
import { getRedis } from '../config/redis';
import { logger } from '../utils/logger';

const BCRYPT_ROUNDS = parseInt(process.env.BCRYPT_ROUNDS || '12');
const JWT_SECRET = process.env.JWT_SECRET!;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

function generateTokens(userId: string, role: string) {
  const accessToken = jwt.sign({ userId, role }, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN,
  });
  const refreshToken = jwt.sign({ userId, type: 'refresh' }, JWT_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d',
  });
  return { accessToken, refreshToken };
}

function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// ============================================================
// REGISTER
// ============================================================

export async function register(req: Request, res: Response, next: NextFunction) {
  try {
    const { full_name, email, phone, password } = req.body;

    if (!email && !phone) {
      throw new AppError('Email or phone is required', 400);
    }

    // Check existing user
    const existing = await query(
      'SELECT id FROM users WHERE email = $1 OR phone = $2',
      [email || null, phone || null]
    );
    if (existing.rowCount > 0) {
      throw new AppError('User with this email or phone already exists', 409);
    }

    const password_hash = await bcrypt.hash(password, BCRYPT_ROUNDS);
    const referral_code = uuidv4().substring(0, 8).toUpperCase();

    const result = await query(
      `INSERT INTO users (full_name, email, phone, password_hash, referral_code)
       VALUES ($1, $2, $3, $4, $5) RETURNING id, full_name, email, phone, role`,
      [full_name, email || null, phone || null, password_hash, referral_code]
    );

    const user = result.rows[0];

    // Send verification OTP
    const otp = generateOTP();
    await query(
      `INSERT INTO otp_codes (user_id, email, phone, code, purpose, expires_at)
       VALUES ($1, $2, $3, $4, 'register', NOW() + INTERVAL '10 minutes')`,
      [user.id, email || null, phone || null, otp]
    );

    if (email) {
      await sendEmail({
        to: email,
        subject: 'Verify your Dipus Candor account',
        template: 'verify-email',
        data: { name: full_name, otp },
      });
    }

    if (phone) {
      await sendSMS(phone, `Your Dipus Candor verification code: ${otp}. Valid for 10 minutes.`);
    }

    const { accessToken, refreshToken } = generateTokens(user.id, user.role);

    res.status(201).json({
      success: true,
      message: `Verification code sent to your ${email ? 'email' : 'phone'}`,
      data: {
        user: { id: user.id, full_name: user.full_name, email: user.email, phone: user.phone, role: user.role },
        accessToken,
        refreshToken,
        requiresVerification: true,
      },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// LOGIN
// ============================================================

export async function login(req: Request, res: Response, next: NextFunction) {
  try {
    const { identifier, password } = req.body; // identifier = email or phone

    const result = await query(
      `SELECT id, full_name, email, phone, password_hash, role, is_active, is_verified, avatar_url
       FROM users WHERE (email = $1 OR phone = $1) AND auth_provider = 'email'`,
      [identifier]
    );

    if (result.rowCount === 0) {
      throw new AppError('Invalid credentials', 401);
    }

    const user = result.rows[0];

    if (!user.is_active) {
      throw new AppError('Your account has been suspended. Contact support.', 403);
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      throw new AppError('Invalid credentials', 401);
    }

    // Update last login
    await query('UPDATE users SET last_login = NOW() WHERE id = $1', [user.id]);

    const { accessToken, refreshToken } = generateTokens(user.id, user.role);

    // Store refresh token
    await query(
      `INSERT INTO refresh_tokens (user_id, token, expires_at)
       VALUES ($1, $2, NOW() + INTERVAL '30 days')`,
      [user.id, refreshToken]
    );

    res.json({
      success: true,
      message: 'Login successful',
      data: {
        user: {
          id: user.id,
          full_name: user.full_name,
          email: user.email,
          phone: user.phone,
          role: user.role,
          is_verified: user.is_verified,
          avatar_url: user.avatar_url,
        },
        accessToken,
        refreshToken,
      },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// VERIFY OTP
// ============================================================

export async function verifyOTP(req: Request, res: Response, next: NextFunction) {
  try {
    const { identifier, code, purpose } = req.body;

    const result = await query(
      `SELECT id, user_id, expires_at, used FROM otp_codes
       WHERE (email = $1 OR phone = $1) AND code = $2 AND purpose = $3
       ORDER BY created_at DESC LIMIT 1`,
      [identifier, code, purpose || 'register']
    );

    if (result.rowCount === 0) {
      throw new AppError('Invalid OTP code', 400);
    }

    const otpRecord = result.rows[0];

    if (otpRecord.used) {
      throw new AppError('OTP already used', 400);
    }

    if (new Date(otpRecord.expires_at) < new Date()) {
      throw new AppError('OTP has expired. Please request a new one.', 400);
    }

    // Mark OTP as used & verify user
    await Promise.all([
      query('UPDATE otp_codes SET used = TRUE WHERE id = $1', [otpRecord.id]),
      query('UPDATE users SET is_verified = TRUE WHERE id = $1', [otpRecord.user_id]),
    ]);

    res.json({ success: true, message: 'Account verified successfully' });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// REFRESH TOKEN
// ============================================================

export async function refreshToken(req: Request, res: Response, next: NextFunction) {
  try {
    const { refreshToken: token } = req.body;

    if (!token) throw new AppError('Refresh token required', 401);

    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string; type: string };

    if (decoded.type !== 'refresh') throw new AppError('Invalid token', 401);

    const stored = await query(
      'SELECT id FROM refresh_tokens WHERE token = $1 AND expires_at > NOW()',
      [token]
    );
    if (stored.rowCount === 0) throw new AppError('Invalid or expired refresh token', 401);

    const userResult = await query(
      'SELECT id, role, is_active FROM users WHERE id = $1',
      [decoded.userId]
    );
    if (userResult.rowCount === 0 || !userResult.rows[0].is_active) {
      throw new AppError('User not found or inactive', 401);
    }

    const user = userResult.rows[0];
    const tokens = generateTokens(user.id, user.role);

    // Rotate refresh token
    await query('DELETE FROM refresh_tokens WHERE token = $1', [token]);
    await query(
      'INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES ($1, $2, NOW() + INTERVAL \'30 days\')',
      [user.id, tokens.refreshToken]
    );

    res.json({ success: true, data: tokens });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// FORGOT PASSWORD
// ============================================================

export async function forgotPassword(req: Request, res: Response, next: NextFunction) {
  try {
    const { identifier } = req.body;

    const result = await query(
      'SELECT id, full_name, email, phone FROM users WHERE email = $1 OR phone = $1',
      [identifier]
    );

    // Always return success to prevent email enumeration
    if (result.rowCount === 0) {
      return res.json({ success: true, message: 'If an account exists, a reset code has been sent.' });
    }

    const user = result.rows[0];
    const otp = generateOTP();

    await query(
      `INSERT INTO otp_codes (user_id, email, phone, code, purpose, expires_at)
       VALUES ($1, $2, $3, $4, 'reset_password', NOW() + INTERVAL '15 minutes')`,
      [user.id, user.email, user.phone, otp]
    );

    if (user.email) {
      await sendEmail({
        to: user.email,
        subject: 'Reset your Dipus Candor password',
        template: 'reset-password',
        data: { name: user.full_name, otp },
      });
    } else if (user.phone) {
      await sendSMS(user.phone, `Your Dipus Candor password reset code: ${otp}. Valid for 15 minutes.`);
    }

    res.json({ success: true, message: 'If an account exists, a reset code has been sent.' });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// RESET PASSWORD
// ============================================================

export async function resetPassword(req: Request, res: Response, next: NextFunction) {
  try {
    const { identifier, code, new_password } = req.body;

    const result = await query(
      `SELECT id, user_id FROM otp_codes
       WHERE (email = $1 OR phone = $1) AND code = $2 AND purpose = 'reset_password'
       AND expires_at > NOW() AND used = FALSE
       ORDER BY created_at DESC LIMIT 1`,
      [identifier, code]
    );

    if (result.rowCount === 0) throw new AppError('Invalid or expired reset code', 400);

    const { id: otpId, user_id } = result.rows[0];
    const password_hash = await bcrypt.hash(new_password, BCRYPT_ROUNDS);

    await Promise.all([
      query('UPDATE users SET password_hash = $1 WHERE id = $2', [password_hash, user_id]),
      query('UPDATE otp_codes SET used = TRUE WHERE id = $1', [otpId]),
      query('DELETE FROM refresh_tokens WHERE user_id = $1', [user_id]),
    ]);

    res.json({ success: true, message: 'Password reset successful. Please login.' });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// LOGOUT
// ============================================================

export async function logout(req: Request, res: Response, next: NextFunction) {
  try {
    const { refreshToken: token } = req.body;
    if (token) {
      await query('DELETE FROM refresh_tokens WHERE token = $1', [token]);
    }
    res.json({ success: true, message: 'Logged out successfully' });
  } catch (error) {
    next(error);
  }
}
