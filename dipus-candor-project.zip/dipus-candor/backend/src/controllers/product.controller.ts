import { Request, Response, NextFunction } from 'express';
import { query, transaction } from '../config/database';
import { AppError } from '../utils/AppError';
import slugify from 'slugify';

// ============================================================
// LIST PRODUCTS (with filters, search, pagination)
// ============================================================

export async function listProducts(req: Request, res: Response, next: NextFunction) {
  try {
    const {
      search, category, brand, minPrice, maxPrice,
      sort = 'created_at', order = 'desc',
      page = '1', limit = '20',
      featured, inStock, tag,
    } = req.query as Record<string, string>;

    const pageNum = Math.max(1, parseInt(page));
    const limitNum = Math.min(100, parseInt(limit));
    const offset = (pageNum - 1) * limitNum;

    let conditions: string[] = ['p.is_active = TRUE'];
    let params: any[] = [];
    let paramIndex = 1;

    if (search) {
      conditions.push(`p.search_vector @@ plainto_tsquery('english', $${paramIndex})`);
      params.push(search);
      paramIndex++;
    }

    if (category) {
      conditions.push(`(p.category_id = $${paramIndex} OR c.slug = $${paramIndex})`);
      params.push(category);
      paramIndex++;
    }

    if (brand) {
      conditions.push(`(p.brand_id = $${paramIndex} OR b.slug = $${paramIndex})`);
      params.push(brand);
      paramIndex++;
    }

    if (minPrice) {
      conditions.push(`p.price >= $${paramIndex}`);
      params.push(parseFloat(minPrice));
      paramIndex++;
    }

    if (maxPrice) {
      conditions.push(`p.price <= $${paramIndex}`);
      params.push(parseFloat(maxPrice));
      paramIndex++;
    }

    if (featured === 'true') {
      conditions.push('p.is_featured = TRUE');
    }

    if (inStock === 'true') {
      conditions.push('p.stock_quantity > 0');
    }

    if (tag) {
      conditions.push(`$${paramIndex} = ANY(p.tags)`);
      params.push(tag);
      paramIndex++;
    }

    const whereClause = conditions.join(' AND ');

    // Valid sort columns
    const sortMap: Record<string, string> = {
      price: 'p.price',
      rating: 'p.rating_avg',
      sold: 'p.sold_count',
      created_at: 'p.created_at',
      name: 'p.name',
      views: 'p.view_count',
    };
    const sortColumn = sortMap[sort] || 'p.created_at';
    const sortOrder = order.toLowerCase() === 'asc' ? 'ASC' : 'DESC';

    const sqlQuery = `
      SELECT
        p.id, p.name, p.slug, p.short_description,
        p.price, p.compare_price, p.stock_quantity,
        p.images, p.rating_avg, p.rating_count,
        p.sold_count, p.is_featured, p.tags,
        c.name as category_name, c.slug as category_slug,
        b.name as brand_name,
        COUNT(*) OVER() as total_count
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN brands b ON p.brand_id = b.id
      WHERE ${whereClause}
      ORDER BY ${sortColumn} ${sortOrder}
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `;

    params.push(limitNum, offset);

    const result = await query(sqlQuery, params);

    const total = result.rowCount > 0 ? parseInt(result.rows[0].total_count) : 0;

    // Increment view counts for search results
    if (result.rowCount > 0) {
      const ids = result.rows.map(r => r.id);
      query(
        `UPDATE products SET view_count = view_count + 1 WHERE id = ANY($1)`,
        [ids]
      ).catch(() => {});
    }

    res.json({
      success: true,
      data: {
        products: result.rows.map(r => ({
          ...r,
          total_count: undefined,
          discount_percentage: r.compare_price > r.price
            ? Math.round((1 - r.price / r.compare_price) * 100)
            : 0,
        })),
        pagination: {
          page: pageNum,
          limit: limitNum,
          total,
          totalPages: Math.ceil(total / limitNum),
          hasNext: pageNum * limitNum < total,
          hasPrev: pageNum > 1,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// GET SINGLE PRODUCT
// ============================================================

export async function getProduct(req: Request, res: Response, next: NextFunction) {
  try {
    const { slug } = req.params;
    const userId = (req as any).user?.userId;

    const result = await query(
      `SELECT
         p.*,
         c.name as category_name, c.slug as category_slug,
         b.name as brand_name, b.logo_url as brand_logo,
         CASE WHEN w.user_id IS NOT NULL THEN TRUE ELSE FALSE END as is_wishlisted
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       LEFT JOIN brands b ON p.brand_id = b.id
       LEFT JOIN wishlists w ON p.id = w.product_id AND w.user_id = $2
       WHERE p.slug = $1 AND p.is_active = TRUE`,
      [slug, userId || null]
    );

    if (result.rowCount === 0) throw new AppError('Product not found', 404);
    const product = result.rows[0];

    // Get variants
    const variantsResult = await query(
      'SELECT * FROM product_variants WHERE product_id = $1 AND is_active = TRUE',
      [product.id]
    );

    // Get reviews (latest 10)
    const reviewsResult = await query(
      `SELECT r.*, u.full_name, u.avatar_url
       FROM product_reviews r
       LEFT JOIN users u ON r.user_id = u.id
       WHERE r.product_id = $1 AND r.is_approved = TRUE
       ORDER BY r.created_at DESC LIMIT 10`,
      [product.id]
    );

    // Get related products
    const relatedResult = await query(
      `SELECT id, name, slug, price, compare_price, images, rating_avg, rating_count
       FROM products
       WHERE category_id = $1 AND id != $2 AND is_active = TRUE
       ORDER BY sold_count DESC LIMIT 6`,
      [product.category_id, product.id]
    );

    // Track recently viewed
    if (userId) {
      query(
        `INSERT INTO recently_viewed (user_id, product_id, viewed_at)
         VALUES ($1, $2, NOW())
         ON CONFLICT (user_id, product_id) DO UPDATE SET viewed_at = NOW()`,
        [userId, product.id]
      ).catch(() => {});
    }

    // Increment view count
    query(
      'UPDATE products SET view_count = view_count + 1 WHERE id = $1',
      [product.id]
    ).catch(() => {});

    res.json({
      success: true,
      data: {
        product: {
          ...product,
          variants: variantsResult.rows,
          discount_percentage: product.compare_price > product.price
            ? Math.round((1 - product.price / product.compare_price) * 100)
            : 0,
        },
        reviews: reviewsResult.rows,
        relatedProducts: relatedResult.rows,
      },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// CREATE PRODUCT (Admin)
// ============================================================

export async function createProduct(req: Request, res: Response, next: NextFunction) {
  try {
    const adminId = (req as any).user.userId;
    const {
      name, description, short_description, price, compare_price,
      cost_price, stock_quantity, low_stock_threshold,
      category_id, brand_id, images, tags, weight_kg,
      dimensions, is_active, is_featured, meta_title, meta_description,
      variants,
    } = req.body;

    const slug = slugify(name, { lower: true, strict: true });

    // Check slug uniqueness
    const existing = await query('SELECT id FROM products WHERE slug = $1', [slug]);
    if (existing.rowCount > 0) throw new AppError('A product with this name already exists', 409);

    const result = await transaction(async (client) => {
      const productResult = await client.query(
        `INSERT INTO products (
           name, slug, description, short_description, price, compare_price,
           cost_price, stock_quantity, low_stock_threshold, category_id, brand_id,
           images, tags, weight_kg, dimensions, is_active, is_featured,
           meta_title, meta_description
         ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
         RETURNING *`,
        [
          name, slug, description, short_description, price, compare_price || null,
          cost_price || null, stock_quantity || 0, low_stock_threshold || 10,
          category_id || null, brand_id || null,
          JSON.stringify(images || []), tags || [], weight_kg || null,
          JSON.stringify(dimensions || {}), is_active !== false, is_featured || false,
          meta_title || null, meta_description || null,
        ]
      );

      const product = productResult.rows[0];

      // Create variants if provided
      if (variants && variants.length > 0) {
        for (const variant of variants) {
          await client.query(
            `INSERT INTO product_variants (product_id, variant_name, attributes, sku, price, stock_quantity, image_url)
             VALUES ($1, $2, $3, $4, $5, $6, $7)`,
            [
              product.id, variant.variant_name, JSON.stringify(variant.attributes),
              variant.sku || null, variant.price || null,
              variant.stock_quantity || 0, variant.image_url || null,
            ]
          );
        }
      }

      // Log admin action
      await client.query(
        `INSERT INTO admin_logs (admin_id, action, target_type, target_id)
         VALUES ($1, 'create_product', 'product', $2)`,
        [adminId, product.id]
      );

      return product;
    });

    res.status(201).json({
      success: true,
      message: 'Product created successfully',
      data: { product: result },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// UPDATE PRODUCT (Admin)
// ============================================================

export async function updateProduct(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const adminId = (req as any).user.userId;
    const updates = req.body;

    const existing = await query('SELECT id FROM products WHERE id = $1', [id]);
    if (existing.rowCount === 0) throw new AppError('Product not found', 404);

    const fields = Object.keys(updates).filter(k =>
      ['name','description','short_description','price','compare_price',
       'stock_quantity','category_id','brand_id','images','tags',
       'is_active','is_featured','meta_title','meta_description'].includes(k)
    );

    if (fields.length === 0) throw new AppError('No valid fields to update', 400);

    const setClause = fields.map((f, i) => `${f} = $${i + 2}`).join(', ');
    const values = fields.map(f => {
      if (['images', 'dimensions'].includes(f)) return JSON.stringify(updates[f]);
      return updates[f];
    });

    await query(
      `UPDATE products SET ${setClause}, updated_at = NOW() WHERE id = $1`,
      [id, ...values]
    );

    await query(
      `INSERT INTO admin_logs (admin_id, action, target_type, target_id, new_values)
       VALUES ($1, 'update_product', 'product', $2, $3)`,
      [adminId, id, JSON.stringify(updates)]
    );

    res.json({ success: true, message: 'Product updated successfully' });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// DELETE PRODUCT (Admin)
// ============================================================

export async function deleteProduct(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const adminId = (req as any).user.userId;

    // Soft delete
    await query('UPDATE products SET is_active = FALSE WHERE id = $1', [id]);

    await query(
      `INSERT INTO admin_logs (admin_id, action, target_type, target_id)
       VALUES ($1, 'delete_product', 'product', $2)`,
      [adminId, id]
    );

    res.json({ success: true, message: 'Product deleted successfully' });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// GET FEATURED / BEST SELLERS / NEW ARRIVALS
// ============================================================

export async function getFeaturedProducts(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await query(
      `SELECT id, name, slug, price, compare_price, images, rating_avg, rating_count, sold_count
       FROM products WHERE is_active = TRUE AND is_featured = TRUE
       ORDER BY sold_count DESC LIMIT 12`
    );
    res.json({ success: true, data: result.rows });
  } catch (error) { next(error); }
}

export async function getBestSellers(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await query(
      `SELECT id, name, slug, price, compare_price, images, rating_avg, rating_count, sold_count
       FROM products WHERE is_active = TRUE
       ORDER BY sold_count DESC LIMIT 12`
    );
    res.json({ success: true, data: result.rows });
  } catch (error) { next(error); }
}

export async function getNewArrivals(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await query(
      `SELECT id, name, slug, price, compare_price, images, rating_avg, rating_count
       FROM products WHERE is_active = TRUE
       ORDER BY created_at DESC LIMIT 12`
    );
    res.json({ success: true, data: result.rows });
  } catch (error) { next(error); }
}

// ============================================================
// AUTOCOMPLETE SEARCH
// ============================================================

export async function searchAutocomplete(req: Request, res: Response, next: NextFunction) {
  try {
    const { q } = req.query as { q: string };
    if (!q || q.length < 2) return res.json({ success: true, data: [] });

    const result = await query(
      `SELECT id, name, slug, price, images
       FROM products
       WHERE is_active = TRUE AND (
         name ILIKE $1 OR
         search_vector @@ plainto_tsquery('english', $2)
       )
       ORDER BY sold_count DESC LIMIT 8`,
      [`%${q}%`, q]
    );

    res.json({ success: true, data: result.rows });
  } catch (error) { next(error); }
}
