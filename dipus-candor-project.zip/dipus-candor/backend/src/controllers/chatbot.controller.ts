import { Request, Response, NextFunction } from 'express';
import OpenAI from 'openai';
import { v4 as uuidv4 } from 'uuid';
import { query } from '../config/database';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

// ============================================================
// SYSTEM PROMPT - Context for the AI
// ============================================================

const SYSTEM_PROMPT = `You are Candor, the helpful AI customer support assistant for Dipus Candor, a modern e-commerce platform.

Your capabilities:
- Help users find products and check availability
- Assist with order tracking and status updates  
- Explain return policy, shipping, and payment options
- Handle order cancellations and modification requests
- Provide personalized product recommendations
- Answer questions about promotions and discounts

Store Information:
- Store: Dipus Candor (dipuscandor.com)
- Return Policy: 30-day hassle-free returns with free pickup
- Delivery: 1-6 days depending on location
- Payment: Stripe (cards), bKash, Cash on Delivery, Wallet
- Support: support@dipuscandor.com | +8801XXXXXXXXX

Tone: Be friendly, helpful, and concise. Use emojis sparingly.
Language: Respond in the same language the user writes in (English or Bengali).

When you cannot help, say: "Let me connect you with our human support team for this."
Never make up information. If unsure, say you'll check and ask for their email.`;

// ============================================================
// SEND MESSAGE
// ============================================================

export async function sendMessage(req: Request, res: Response, next: NextFunction) {
  try {
    const { message, sessionToken } = req.body;
    const userId = (req as any).user?.userId;

    if (!message?.trim()) throw new AppError('Message is required', 400);

    // Get or create session
    let sessionId: string;
    let existingMessages: Message[] = [];

    if (sessionToken) {
      const sessionResult = await query(
        'SELECT id, messages FROM chat_sessions WHERE session_token = $1',
        [sessionToken]
      );
      if (sessionResult.rowCount > 0) {
        sessionId = sessionResult.rows[0].id;
        existingMessages = sessionResult.rows[0].messages || [];
      }
    }

    if (!sessionId!) {
      const newToken = uuidv4();
      const sessionResult = await query(
        `INSERT INTO chat_sessions (user_id, session_token, messages)
         VALUES ($1, $2, '[]') RETURNING id, session_token`,
        [userId || null, newToken]
      );
      sessionId = sessionResult.rows[0].id;
    }

    // Fetch relevant context
    const context = await buildContext(message, userId);

    // Build messages array
    const messages: Message[] = [
      { role: 'system', content: SYSTEM_PROMPT + '\n\n' + context },
      ...existingMessages.slice(-10), // Last 10 messages for context
      { role: 'user', content: message },
    ];

    // Call OpenAI
    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4-turbo-preview',
      messages,
      max_tokens: 500,
      temperature: 0.7,
    });

    const assistantMessage = completion.choices[0].message.content || 
      'I apologize, I had trouble understanding. Could you rephrase that?';

    // Sentiment analysis
    const sentiment = analyzeSentiment(message);

    // Update session
    const updatedMessages = [
      ...existingMessages,
      { role: 'user', content: message, timestamp: new Date() },
      { role: 'assistant', content: assistantMessage, timestamp: new Date() },
    ];

    await query(
      `UPDATE chat_sessions SET
         messages = $1::jsonb,
         sentiment_score = $2,
         is_escalated = $3,
         updated_at = NOW()
       WHERE id = $4`,
      [
        JSON.stringify(updatedMessages),
        sentiment.score,
        sentiment.score < -0.5, // Escalate if very negative
        sessionId,
      ]
    );

    // Check for special intents
    const actionSuggestions = detectIntents(message, assistantMessage);

    res.json({
      success: true,
      data: {
        message: assistantMessage,
        sessionToken: sessionToken || await getSessionToken(sessionId),
        actions: actionSuggestions,
        isEscalated: sentiment.score < -0.5,
      },
    });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// GET SESSION HISTORY
// ============================================================

export async function getSessionHistory(req: Request, res: Response, next: NextFunction) {
  try {
    const { sessionToken } = req.params;

    const result = await query(
      `SELECT session_token, messages, created_at, updated_at
       FROM chat_sessions WHERE session_token = $1`,
      [sessionToken]
    );

    if (result.rowCount === 0) {
      return res.json({ success: true, data: { messages: [] } });
    }

    res.json({ success: true, data: result.rows[0] });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// RESOLVE SESSION
// ============================================================

export async function resolveSession(req: Request, res: Response, next: NextFunction) {
  try {
    const { sessionToken } = req.params;

    await query(
      'UPDATE chat_sessions SET resolved = TRUE WHERE session_token = $1',
      [sessionToken]
    );

    res.json({ success: true, message: 'Session resolved' });
  } catch (error) {
    next(error);
  }
}

// ============================================================
// HELPER FUNCTIONS
// ============================================================

async function buildContext(message: string, userId?: string): Promise<string> {
  let context = '';

  try {
    // Search relevant FAQs
    const faqResult = await query(
      `SELECT question, answer FROM chatbot_faqs
       WHERE is_active = TRUE AND (
         question ILIKE $1 OR answer ILIKE $1
       ) LIMIT 3`,
      [`%${message.split(' ').slice(0, 3).join('%')}%`]
    );

    if (faqResult.rowCount > 0) {
      context += '\nKnowledge Base:\n';
      faqResult.rows.forEach(faq => {
        context += `Q: ${faq.question}\nA: ${faq.answer}\n`;
      });
    }

    // If user is logged in, get their context
    if (userId) {
      const userResult = await query(
        `SELECT u.full_name, u.loyalty_points, u.wallet_balance,
           COUNT(o.id) as total_orders,
           MAX(o.created_at) as last_order_date
         FROM users u
         LEFT JOIN orders o ON u.id = o.user_id
         WHERE u.id = $1
         GROUP BY u.id, u.full_name, u.loyalty_points, u.wallet_balance`,
        [userId]
      );

      if (userResult.rowCount > 0) {
        const user = userResult.rows[0];
        context += `\nCustomer Context:
Name: ${user.full_name}
Total Orders: ${user.total_orders}
Loyalty Points: ${user.loyalty_points}
Wallet Balance: ৳${user.wallet_balance}`;
      }

      // Check for order query
      const orderMatch = message.match(/DIP\d+/i);
      if (orderMatch) {
        const orderNum = orderMatch[0].toUpperCase();
        const orderResult = await query(
          `SELECT o.order_number, o.status, o.payment_status,
             o.grand_total, o.estimated_delivery, o.tracking_id,
             json_agg(oi.product_name) as items
           FROM orders o
           JOIN order_items oi ON o.id = oi.order_id
           WHERE o.order_number = $1 AND o.user_id = $2
           GROUP BY o.id, o.order_number, o.status, o.payment_status,
             o.grand_total, o.estimated_delivery, o.tracking_id`,
          [orderNum, userId]
        );

        if (orderResult.rowCount > 0) {
          const order = orderResult.rows[0];
          context += `\n\nOrder Details for ${orderNum}:
Status: ${order.status}
Payment: ${order.payment_status}
Total: ৳${order.grand_total}
Items: ${order.items?.join(', ')}
Estimated Delivery: ${order.estimated_delivery || 'Calculating...'}
Tracking ID: ${order.tracking_id || 'Not yet assigned'}`;
        }
      }
    }

    // Search products if relevant
    if (message.toLowerCase().includes('product') ||
        message.toLowerCase().includes('buy') ||
        message.toLowerCase().includes('find') ||
        message.toLowerCase().includes('show')) {
      const productResult = await query(
        `SELECT name, price, compare_price, rating_avg, stock_quantity
         FROM products
         WHERE is_active = TRUE AND search_vector @@ plainto_tsquery('english', $1)
         ORDER BY sold_count DESC LIMIT 5`,
        [message]
      );

      if (productResult.rowCount > 0) {
        context += '\n\nRelevant Products:\n';
        productResult.rows.forEach(p => {
          const discount = p.compare_price > p.price
            ? ` (${Math.round((1 - p.price/p.compare_price) * 100)}% off)`
            : '';
          context += `- ${p.name}: ৳${p.price}${discount} | Rating: ${p.rating_avg}★ | Stock: ${p.stock_quantity > 0 ? 'In Stock' : 'Out of Stock'}\n`;
        });
      }
    }
  } catch (error) {
    logger.error('Error building chatbot context:', error);
  }

  return context;
}

function analyzeSentiment(text: string): { score: number; label: string } {
  const positiveWords = ['great', 'excellent', 'love', 'happy', 'good', 'thanks', 'wonderful', 'amazing', 'perfect'];
  const negativeWords = ['bad', 'terrible', 'awful', 'angry', 'frustrated', 'annoyed', 'wrong', 'broken', 'scam', 'fake', 'refund', 'cancel'];

  const lowerText = text.toLowerCase();
  let score = 0;

  positiveWords.forEach(word => { if (lowerText.includes(word)) score += 0.2; });
  negativeWords.forEach(word => { if (lowerText.includes(word)) score -= 0.25; });

  score = Math.max(-1, Math.min(1, score));
  const label = score > 0.2 ? 'positive' : score < -0.2 ? 'negative' : 'neutral';

  return { score, label };
}

function detectIntents(userMessage: string, botResponse: string): Array<{type: string; label: string; data?: any}> {
  const actions = [];
  const lower = userMessage.toLowerCase();

  if (lower.includes('track') || lower.includes('where is my order')) {
    actions.push({ type: 'navigate', label: '📦 Track My Order', data: { path: '/orders' } });
  }

  if (lower.includes('return') || lower.includes('refund')) {
    actions.push({ type: 'navigate', label: '↩️ Start Return', data: { path: '/returns' } });
  }

  if (lower.includes('product') || lower.includes('buy') || lower.includes('shop')) {
    actions.push({ type: 'navigate', label: '🛍️ Browse Products', data: { path: '/products' } });
  }

  if (lower.includes('talk') || lower.includes('human') || lower.includes('agent')) {
    actions.push({ type: 'contact', label: '💬 Talk to Human', data: { email: 'support@dipuscandor.com' } });
  }

  return actions;
}

async function getSessionToken(sessionId: string): Promise<string> {
  const result = await query('SELECT session_token FROM chat_sessions WHERE id = $1', [sessionId]);
  return result.rows[0]?.session_token || '';
}
