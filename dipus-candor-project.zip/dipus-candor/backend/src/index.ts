import express, { Application, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import { createServer } from 'http';
import { Server } from 'socket.io';
import dotenv from 'dotenv';

dotenv.config();

import { connectDB } from './config/database';
import { connectRedis } from './config/redis';
import { logger } from './utils/logger';

// Routes
import authRoutes from './routes/auth.routes';
import productRoutes from './routes/product.routes';
import categoryRoutes from './routes/category.routes';
import cartRoutes from './routes/cart.routes';
import orderRoutes from './routes/order.routes';
import paymentRoutes from './routes/payment.routes';
import userRoutes from './routes/user.routes';
import chatbotRoutes from './routes/chatbot.routes';
import adminRoutes from './routes/admin.routes';
import deliveryRoutes from './routes/delivery.routes';
import reviewRoutes from './routes/review.routes';
import wishlistRoutes from './routes/wishlist.routes';
import notificationRoutes from './routes/notification.routes';

const app: Application = express();
const httpServer = createServer(app);

// Socket.io for real-time tracking
const io = new Server(httpServer, {
  cors: {
    origin: process.env.APP_URL || 'http://localhost:3000',
    credentials: true,
  },
});

// ============================================================
// MIDDLEWARE
// ============================================================

app.use(helmet({ contentSecurityPolicy: false }));

app.use(cors({
  origin: [
    process.env.APP_URL || 'http://localhost:3000',
    'http://localhost:3001', // admin
  ],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(morgan('combined', {
  stream: { write: (msg) => logger.info(msg.trim()) }
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'),
  max: parseInt(process.env.RATE_LIMIT_MAX || '100'),
  message: { success: false, message: 'Too many requests. Please try again later.' },
});
app.use('/api/', limiter);

// Stripe webhook (raw body required)
app.use('/api/payments/webhook', express.raw({ type: 'application/json' }));

// ============================================================
// ROUTES
// ============================================================

const API_V1 = '/api/v1';

app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), service: 'Dipus Candor API' });
});

app.use(`${API_V1}/auth`, authRoutes);
app.use(`${API_V1}/products`, productRoutes);
app.use(`${API_V1}/categories`, categoryRoutes);
app.use(`${API_V1}/cart`, cartRoutes);
app.use(`${API_V1}/orders`, orderRoutes);
app.use(`${API_V1}/payments`, paymentRoutes);
app.use(`${API_V1}/users`, userRoutes);
app.use(`${API_V1}/chatbot`, chatbotRoutes);
app.use(`${API_V1}/admin`, adminRoutes);
app.use(`${API_V1}/delivery`, deliveryRoutes);
app.use(`${API_V1}/reviews`, reviewRoutes);
app.use(`${API_V1}/wishlist`, wishlistRoutes);
app.use(`${API_V1}/notifications`, notificationRoutes);

// ============================================================
// SOCKET.IO - Real-time order tracking
// ============================================================

io.on('connection', (socket) => {
  logger.info(`Socket connected: ${socket.id}`);

  socket.on('join_order_room', (orderId: string) => {
    socket.join(`order:${orderId}`);
    logger.info(`Socket ${socket.id} joined order room: ${orderId}`);
  });

  socket.on('delivery_location_update', async (data: {
    orderId: string;
    lat: number;
    lng: number;
    deliveryPartnerId: string;
  }) => {
    io.to(`order:${data.orderId}`).emit('location_update', {
      lat: data.lat,
      lng: data.lng,
      timestamp: new Date().toISOString(),
    });
  });

  socket.on('disconnect', () => {
    logger.info(`Socket disconnected: ${socket.id}`);
  });
});

// Export io for use in other modules
export { io };

// ============================================================
// ERROR HANDLER
// ============================================================

app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  logger.error(err.stack || err.message);

  const statusCode = err.statusCode || err.status || 500;
  const message = err.message || 'Internal server error';

  res.status(statusCode).json({
    success: false,
    message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
});

app.use((req: Request, res: Response) => {
  res.status(404).json({ success: false, message: 'Route not found' });
});

// ============================================================
// START SERVER
// ============================================================

const PORT = parseInt(process.env.PORT || '5000');

async function startServer() {
  try {
    await connectDB();
    await connectRedis();

    httpServer.listen(PORT, () => {
      logger.info(`🚀 Dipus Candor API running on port ${PORT}`);
      logger.info(`📖 Environment: ${process.env.NODE_ENV}`);
    });
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export default app;
